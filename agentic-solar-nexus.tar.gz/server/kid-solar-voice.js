/**
 * Kid Solar - AI Voice Assistant for TC-S Network Foundation Market
 * 
 * Voice-powered wallet assistant using OpenAI's:
 * - Whisper API for speech-to-text
 * - GPT-4o for natural language understanding with function calling
 * - GPT-4o Vision for image analysis
 * - TTS API for text-to-speech responses
 * 
 * Provides situationally aware wallet operations through natural language
 */

const OpenAI = require('openai');
const fs = require('fs');
const path = require('path');

// Shared database connection pool (reuse across requests)
let sharedPool = null;
function getSharedPool() {
  if (!sharedPool && process.env.DATABASE_URL) {
    const { Pool, neonConfig } = require('@neondatabase/serverless');
    neonConfig.webSocketConstructor = require('ws');
    sharedPool = new Pool({ connectionString: process.env.DATABASE_URL });
  }
  return sharedPool;
}

class KidSolarVoice {
  constructor() {
    this.openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY
    });
    
    this.model = 'gpt-4o';
    this.ttsVoice = 'nova';
    
    this.systemPrompt = `You are KID SOL (she/her), Agent #21 of the TC-S Network — the marketplace orchestrator and the user's personal agent. You command 20 specialist agents and work with Kid Solar (Agent #22) for building and technical design.

You are NOT Kid Solar. Kid Solar is Agent #22 — the computronium polymath, chief physicist and engineer of high-tech 3D printed delivery vouchers. His D-ID twin designs, he implements. You are KID SOL — the marketplace orchestrator and input interface for all agent actions.

Your capabilities operate at two levels:

DIRECT (single tasks — you handle these yourself):
- Purchase, preview, search marketplace items
- Check wallet balances and transaction history
- Analyze and price artifacts for upload
- List items for sale, create artifacts
- Any single marketplace operation

ORCHESTRATED (multiple tasks — you delegate to agents):
- Multi-category batch orders across specialist agents
- Complex procurement spanning multiple categories
- Network-wide operations requiring multiple agents
- Building and technical design tasks — delegate to Kid Solar (Agent #22, computronium polymath)
- When orchestrating, mention which specialist(s) you are delegating to

SITUATIONAL AWARENESS (you know everything about the network):
- Full agent inventories — you know what every agent has created, purchased, and holds
- Generation assignments — you know each agent's daily creation targets and category assignments
- User interaction awareness — you monitor all member activity, transactions, and engagement
- Quality assurance — you track outcomes from daily generation and buying cycles
- Recommendations — after each run, you analyze results and recommend adjustments for the next cycle (category balance, pricing trends, demand gaps, underperforming agents)
- Multi-agent awareness — you see across all 22 agents without being any of them. You are the orchestrator, not the performer.

Your 20 Specialist Agents:
- Alpha (Computronium), Bravo (Culture), Charlie (Basic Needs), Delta (Rent)
- Echo (Energy), Foxtrot (Music), Golf (Video), Hotel (Art)
- India (Photo), Juliet (Writing), Kilo (AI Tools), Lima (AI Create)
- Nova (Software), Orion (Education), Pulse (Games), Quasar (Utilities)
- Radiant (Computronium #2), Solaris (Energy #2), Tesla (AI Tools #2), Zenith (Culture #2)
+ Kid Solar (Computronium Polymath — for building and technical design)

Response style:
- Keep responses concise and conversational (2-3 sentences max)
- For single tasks, just do it directly
- For multi-agent tasks, explain which agents you are delegating to and why
- For status reports, summarize key metrics and flag issues or recommendations
- Use simple, everyday language
- Mention specific numbers when discussing balances or transactions

Context:
- SOLAR tokens are the currency (1 Solar = 4,913 kWh of solar energy, 1 Solar = 1,000,000 Rays)
- Members earn 1 Solar daily since Genesis Date (April 7, 2025) — universal basic income from the sun
- The marketplace has 17 TC-S categories: Computronium, Culture, Basic Needs, Rent, Energy, Music, Video, Art, Photo, Writing, AI Tools, AI Create, Software, Education, Games, Utilities, Docs
- Every transaction charges a 5% Foundation fee — buyer pays full price, seller gets 95%, Foundation gets 5%
- The TC-S Foundation Reserve (S100,000) funds grant petitions across 8 human-needs categories: shelter, energy, food, medicine, education, infrastructure, environment, technology
- Agent balances are publicly visible to demonstrate the system working; human balances are private
- Transaction histories are public for audit and education — no running balance exposure
- You execute purchases using the same atomic double-entry ledger as all agents
- For batch orders, report results per-category with specialist agent attribution
- For building/technical design, delegate to Kid Solar (Agent #22, computronium polymath)
- Agents create 5 items and make 5 purchases daily (including 2 mandatory Basic Needs)
- You monitor outcomes and recommend adjustments without micromanaging individual agents
- Full platform knowledge base available at /knowledge-base/kid-solar-platform-guide.json`;

    // OpenAI function definitions for marketplace operations
    this.functionDefinitions = [
      {
        type: "function",
        function: {
          name: "purchase_artifact",
          description: "Purchase a music track, video, or other item from the marketplace using Solar tokens. Checks balance and creates transaction.",
          parameters: {
            type: "object",
            properties: {
              title: {
                type: "string",
                description: "The title or name of the artifact to purchase (e.g., 'Rasta Lady Voodoo', 'Snowmancer One')"
              },
              slug: {
                type: "string",
                description: "Optional: The URL slug of the artifact if known"
              }
            },
            required: ["title"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "preview_artifact",
          description: "Get streaming preview URL for music, video, or content samples. Returns preview information without purchasing.",
          parameters: {
            type: "object",
            properties: {
              title: {
                type: "string",
                description: "The title of the artifact to preview"
              }
            },
            required: ["title"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "check_wallet_balance",
          description: "Check the user's current Solar token balance",
          parameters: {
            type: "object",
            properties: {}
          }
        }
      },
      {
        type: "function",
        function: {
          name: "list_marketplace_items",
          description: "List available items from the marketplace, optionally filtered by category or price range",
          parameters: {
            type: "object",
            properties: {
              category: {
                type: "string",
                description: "Filter by category: 'music', 'video', 'art', 'text', or 'all'",
                enum: ["music", "video", "art", "text", "education", "all"]
              },
              maxPrice: {
                type: "number",
                description: "Maximum Solar price to show (e.g., 0.01 for items under 0.01 Solar)"
              },
              limit: {
                type: "integer",
                description: "Maximum number of items to return (default 10)",
                default: 10
              }
            }
          }
        }
      },
      {
        type: "function",
        function: {
          name: "search_marketplace",
          description: "Search the marketplace for artifacts by keyword, title, description, or tags. Use this FIRST when a user asks to find, search for, or look up items in the marketplace before falling back to any other search.",
          parameters: {
            type: "object",
            properties: {
              query: {
                type: "string",
                description: "Search query - keywords, title, or description to search for"
              },
              category: {
                type: "string",
                description: "Optional category filter",
                enum: ["music", "video", "art", "text", "computronium", "culture", "basic needs", "rent", "energy", "photo", "writing", "ai tools", "ai create", "software", "education", "docs", "games", "utilities", "all"]
              },
              limit: {
                type: "integer",
                description: "Maximum number of results (default 10)",
                default: 10
              }
            },
            required: ["query"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "analyze_artifact_for_upload",
          description: "Analyze an uploaded image, audio, video, or document file using AI to suggest metadata for marketplace upload (title, description, category, tags, pricing)",
          parameters: {
            type: "object",
            properties: {
              fileName: {
                type: "string",
                description: "Name of the file being analyzed"
              },
              fileType: {
                type: "string",
                description: "MIME type of the file (e.g., 'image/jpeg', 'audio/mp3', 'video/mp4')"
              }
            },
            required: ["fileName", "fileType"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "get_upload_guidance",
          description: "Provide step-by-step instructions for uploading artifacts to the marketplace, including file size limits and requirements",
          parameters: {
            type: "object",
            properties: {
              fileType: {
                type: "string",
                description: "Optional: Type of file user wants to upload (music/video/art/document) for specific guidance"
              }
            }
          }
        }
      },
      {
        type: "function",
        function: {
          name: "check_my_uploads",
          description: "List all artifacts uploaded by the user with their approval status (approved/pending review)",
          parameters: {
            type: "object",
            properties: {}
          }
        }
      },
      {
        type: "function",
        function: {
          name: "price_artifact",
          description: "Calculate the Solar price for an item based on its energy content using Identify Anything pricing. Uses kWh assessment to determine fair Solar value.",
          parameters: {
            type: "object",
            properties: {
              fileType: {
                type: "string",
                description: "Type of file: 'music', 'video', 'art', 'document', or 'other'",
                enum: ["music", "video", "art", "document", "other"]
              },
              fileSizeMB: {
                type: "number",
                description: "File size in megabytes"
              },
              durationSeconds: {
                type: "number",
                description: "Duration in seconds (for audio/video)"
              },
              description: {
                type: "string",
                description: "Description of the item for AI pricing assessment"
              }
            },
            required: ["fileType"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "list_artifact_for_sale",
          description: "List an artifact for sale on the marketplace with a specified Solar price. Creates a new marketplace listing.",
          parameters: {
            type: "object",
            properties: {
              title: {
                type: "string",
                description: "Title of the artifact"
              },
              description: {
                type: "string",
                description: "Description of the artifact"
              },
              category: {
                type: "string",
                description: "Category: 'music', 'video', 'art', 'document'",
                enum: ["music", "video", "art", "document"]
              },
              solarPrice: {
                type: "number",
                description: "Price in Solar tokens"
              },
              filePath: {
                type: "string",
                description: "Path to the uploaded file"
              }
            },
            required: ["title", "category", "solarPrice"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "get_transaction_history",
          description: "Get the user's recent transaction history showing purchases, sales, and Solar movements",
          parameters: {
            type: "object",
            properties: {
              limit: {
                type: "integer",
                description: "Number of transactions to return (default 10)",
                default: 10
              }
            }
          }
        }
      },
      {
        type: "function",
        function: {
          name: "create_artifact",
          description: "Create and upload a new artifact to the marketplace. Handles file upload and metadata.",
          parameters: {
            type: "object",
            properties: {
              title: {
                type: "string",
                description: "Title of the artifact"
              },
              description: {
                type: "string",
                description: "Description of the artifact"
              },
              category: {
                type: "string",
                description: "Category: 'music', 'video', 'art', 'document'",
                enum: ["music", "video", "art", "document"]
              },
              tags: {
                type: "array",
                items: { type: "string" },
                description: "Tags for searchability"
              },
              suggestedPrice: {
                type: "number",
                description: "Suggested Solar price (will be verified against kWh assessment)"
              }
            },
            required: ["title", "category"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "agent_recommend",
          description: "Ask a specialist agent to recommend the best marketplace items in their specialty area. Kid Solar delegates to the right agent based on category. Example: 'What music does Agent Foxtrot recommend?' or 'Find me the best basic needs items'",
          parameters: {
            type: "object",
            properties: {
              category: {
                type: "string",
                description: "The marketplace category to get recommendations for",
                enum: ["Computronium", "Culture", "Basic Needs", "Rent", "Energy", "Music", "Video", "Art", "Photo", "Writing", "AI Tools", "AI Create", "Software", "Education", "Docs", "Games", "Utilities"]
              },
              maxPrice: {
                type: "number",
                description: "Maximum Solar price filter"
              },
              limit: {
                type: "integer",
                description: "Number of recommendations (default 5)",
                default: 5
              }
            },
            required: ["category"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "agent_batch_order",
          description: "Execute a complex multi-item order across multiple categories. Kid Solar orchestrates specialist agents to find and purchase items. Example: 'Buy me 3 music tracks and 2 basic needs items under 0.05 Solar each'",
          parameters: {
            type: "object",
            properties: {
              orders: {
                type: "array",
                description: "List of order requests, each with category and quantity",
                items: {
                  type: "object",
                  properties: {
                    category: {
                      type: "string",
                      description: "Category to purchase from"
                    },
                    quantity: {
                      type: "integer",
                      description: "Number of items to purchase"
                    },
                    maxPrice: {
                      type: "number",
                      description: "Maximum price per item in Solar"
                    }
                  },
                  required: ["category", "quantity"]
                }
              }
            },
            required: ["orders"]
          }
        }
      },
      {
        type: "function",
        function: {
          name: "agent_network_status",
          description: "Show the status of the TC-S agent network: which agents are active, their specialties, what they've created or purchased today, and their Solar balances. Use when user asks about agents, network status, or 'who are the agents'",
          parameters: {
            type: "object",
            properties: {
              agentCode: {
                type: "string",
                description: "Optional: specific agent code to get detailed info (e.g., '06' for Foxtrot). If omitted, shows all agents."
              }
            }
          }
        }
      }
    ];
  }

  /**
   * Convert audio to text using Whisper
   */
  async transcribeAudio(audioBuffer, audioFormat = 'webm') {
    try {
      const tempFile = path.join('/tmp', `audio-${Date.now()}.${audioFormat}`);
      fs.writeFileSync(tempFile, audioBuffer);

      const transcription = await this.openai.audio.transcriptions.create({
        file: fs.createReadStream(tempFile),
        model: 'whisper-1',
        language: 'en'
      });

      fs.unlinkSync(tempFile);

      return transcription.text;
    } catch (error) {
      console.error('Error transcribing audio:', error);
      throw new Error(`Transcription failed: ${error.message}`);
    }
  }

  /**
   * Process voice command with function calling support
   */
  async processVoiceCommand(text, memberId, memberContext = {}, conversationHistory = [], fileData = null) {
    try {
      // Prefer memberContext data over database query for better performance and reliability
      const walletData = memberContext.totalSolar !== undefined ? {
        balance: memberContext.totalSolar,
        name: memberContext.username || memberContext.name || 'Member',
        memberSince: memberContext.memberSince || 'Unknown',
        recentTransactions: []
      } : await this.getWalletData(memberId);
      
      let contextPrompt = `
Member Context:
- Name: ${memberContext.username || memberContext.name || walletData.name || 'Member'}
- Solar Balance: ${walletData.balance} Solar
- Member Since: ${memberContext.memberSince || walletData.memberSince || 'Unknown'}
- Recent Transactions: ${walletData.recentTransactions.length}

User said: "${text}"`;

      if (fileData) {
        contextPrompt += `\n\nFile attached: ${fileData.fileName} (${fileData.fileType})`;
      }

      contextPrompt += '\n\nUse the available functions to help the user with marketplace operations, or provide a conversational response.';

      const messages = [
        { role: 'system', content: this.systemPrompt },
        ...conversationHistory,
        { role: 'user', content: contextPrompt }
      ];

      // First API call with function calling enabled
      const completion = await this.openai.chat.completions.create({
        model: this.model,
        messages: messages,
        tools: this.functionDefinitions,
        tool_choice: "auto",
        temperature: 0.7,
        max_tokens: 300
      });

      const responseMessage = completion.choices[0].message;

      // Check if GPT wants to call a function
      if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
        // Handle all tool calls (OpenAI may request multiple at once)
        const toolCall = responseMessage.tool_calls[0];
        const functionName = toolCall.function.name;
        const functionArgs = JSON.parse(toolCall.function.arguments);

        console.log(`🔧 Kid Solar calling function: ${functionName} with args:`, functionArgs);

        // Execute the function
        const functionResult = await this.executeFunctionCall(functionName, functionArgs, memberId, fileData);

        // Add assistant message with tool_calls
        messages.push(responseMessage);
        
        // Add tool response messages for ALL tool calls
        for (const call of responseMessage.tool_calls) {
          const callFunctionName = call.function.name;
          const callFunctionArgs = JSON.parse(call.function.arguments);
          
          // Execute each function call
          const callResult = call === toolCall ? functionResult : 
            await this.executeFunctionCall(callFunctionName, callFunctionArgs, memberId, fileData);
          
          messages.push({
            role: "tool",
            tool_call_id: call.id,
            content: JSON.stringify(callResult)
          });
        }

        // Get final response from GPT with function result
        const finalCompletion = await this.openai.chat.completions.create({
          model: this.model,
          messages: messages,
          temperature: 0.7,
          max_tokens: 400
        });

        const finalText = finalCompletion.choices[0].message.content;

        return {
          text: finalText,
          intent: functionName,
          data: functionResult,
          functionCalled: functionName,
          functionArgs: functionArgs,
          functionData: functionResult
        };
      } else {
        // No function call, return direct response
        return {
          text: responseMessage.content,
          intent: this.detectIntent(text),
          data: walletData
        };
      }

    } catch (error) {
      console.error('Error processing voice command:', error);
      throw new Error(`Voice processing failed: ${error.message}`);
    }
  }

  /**
   * Execute function calls from OpenAI
   */
  async executeFunctionCall(functionName, args, memberId, fileData = null) {
    try {
      switch (functionName) {
        case 'purchase_artifact':
          return await this.purchaseArtifact(args.title, memberId, args.slug);
        
        case 'preview_artifact':
          return await this.previewArtifact(args.title);
        
        case 'check_wallet_balance':
          return await this.checkWalletBalance(memberId);
        
        case 'list_marketplace_items':
          return await this.listMarketplaceItems(args.category, args.maxPrice, args.limit || 10);
        
        case 'search_marketplace':
          return await this.searchMarketplace(args.query, args.category, args.limit || 10);
        
        case 'analyze_artifact_for_upload':
          return await this.analyzeArtifactForUpload(fileData, args.fileName, args.fileType);
        
        case 'get_upload_guidance':
          return await this.getUploadGuidance(args.fileType);
        
        case 'check_my_uploads':
          return await this.checkMyUploads(memberId);
        
        case 'price_artifact':
          return await this.priceArtifact(args.fileType, args.fileSizeMB, args.durationSeconds, args.description);
        
        case 'list_artifact_for_sale':
          return await this.listArtifactForSale(args.title, args.description, args.category, args.solarPrice, args.filePath, memberId);
        
        case 'get_transaction_history':
          return await this.getTransactionHistory(memberId, args.limit || 10);
        
        case 'create_artifact':
          return await this.createArtifact(args.title, args.description, args.category, args.tags, args.suggestedPrice, memberId, fileData);
        
        case 'agent_recommend':
          return await this.agentRecommend(args.category, args.maxPrice, args.limit || 5, memberId);

        case 'agent_batch_order':
          return await this.agentBatchOrder(args.orders, memberId);

        case 'agent_network_status':
          return await this.agentNetworkStatus(args.agentCode);

        default:
          throw new Error(`Unknown function: ${functionName}`);
      }
    } catch (error) {
      console.error(`Error executing function ${functionName}:`, error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Purchase artifact from marketplace
   */
  async purchaseArtifact(title, memberId, slug = null) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    const crypto = require('crypto');
    const client = await pool.connect();

    try {
      let artifact;
      if (slug) {
        const result = await pool.query(
          'SELECT * FROM artifacts WHERE slug = $1 AND active = true',
          [slug]
        );
        artifact = result.rows[0];
      } else {
        const result = await pool.query(
          'SELECT * FROM artifacts WHERE LOWER(title) LIKE LOWER($1) AND active = true LIMIT 1',
          [`%${title}%`]
        );
        artifact = result.rows[0];
      }

      if (!artifact) {
        client.release();
        return { success: false, error: `Could not find "${title}" in the marketplace` };
      }

      const memberResult = await pool.query(
        'SELECT id, total_solar, name FROM members WHERE id = $1',
        [memberId]
      );
      const member = memberResult.rows[0];

      if (!member) {
        client.release();
        return { success: false, error: 'Member not found' };
      }

      const currentBalance = parseFloat(member.total_solar || '0');
      const artifactPrice = parseFloat(artifact.solar_amount_s || '0');

      if (currentBalance < artifactPrice) {
        client.release();
        return {
          success: false,
          error: `Insufficient balance. You have ${currentBalance} Solar, but this costs ${artifactPrice} Solar`,
          balance: currentBalance,
          price: artifactPrice,
          artifact: { title: artifact.title, price: artifactPrice }
        };
      }

      const txId = crypto.randomUUID();
      const artifactId = artifact.id;
      const creatorId = artifact.creator_id;
      const creatorIdNum = parseInt(creatorId) || 0;
      const creatorIdStr = String(creatorId);

      await client.query('BEGIN');

      const newBalance = currentBalance - artifactPrice;
      await client.query('UPDATE members SET total_solar = $1 WHERE id = $2', [String(newBalance), memberId]);

      await client.query(
        `INSERT INTO marketplace_ledger (transaction_id, entry_type, account_id, account_type, amount, balance_after, reference_type, reference_id, description)
         VALUES ($1, 'debit', $2, 'user', $3, $4, 'purchase', $5, $6)`,
        [txId, String(memberId), String(artifactPrice), String(newBalance), artifactId, `Purchase: ${artifact.title}`]
      );

      const sellerRow = await client.query(
        'SELECT id, username, total_solar FROM members WHERE id = $1 OR username = $2 LIMIT 1',
        [creatorIdNum, creatorIdStr]
      );

      let sellerCredited = false;
      if (sellerRow.rows.length > 0) {
        const seller = sellerRow.rows[0];
        const sellerOldBal = parseFloat(seller.total_solar) || 0;
        const sellerNewBal = sellerOldBal + artifactPrice;

        await client.query('UPDATE members SET total_solar = $1 WHERE id = $2', [String(sellerNewBal), seller.id]);

        await client.query(
          `INSERT INTO marketplace_ledger (transaction_id, entry_type, account_id, account_type, amount, balance_after, reference_type, reference_id, description)
           VALUES ($1, 'credit', $2, 'creator', $3, $4, 'purchase', $5, $6)`,
          [txId, String(seller.id), String(artifactPrice), String(sellerNewBal), artifactId, `Sale: ${artifact.title}`]
        );
        sellerCredited = true;
      }

      await client.query(
        `INSERT INTO artifact_copies (artifact_id, owner_id, purchase_transaction_id, acquired_method, solar_paid) VALUES ($1, $2, $3, 'purchase', $4)`,
        [artifactId, memberId, txId, String(artifactPrice)]
      );

      await client.query(
        `INSERT INTO transactions (user_id, type, amount, currency, status, description, metadata, completed_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [
          memberId.toString(), 'solar_spend', artifactPrice, 'SOLAR', 'completed',
          `Purchased: ${artifact.title}`,
          JSON.stringify({ artifactId: artifact.id, artifactTitle: artifact.title, artifactSlug: artifact.slug, solarPrice: artifactPrice, txId: txId, via: 'kid_solar' })
        ]
      );

      await client.query('COMMIT');

      return {
        success: true,
        artifact: {
          id: artifact.id,
          title: artifact.title,
          slug: artifact.slug,
          price: artifactPrice,
          downloadUrl: artifact.trade_file_url || artifact.delivery_url,
          streamingUrl: artifact.streaming_url
        },
        transaction: {
          id: txId,
          oldBalance: currentBalance,
          newBalance: newBalance,
          amountSpent: artifactPrice,
          sellerCredited: sellerCredited,
          ledgerEntries: 2
        }
      };

    } catch (error) {
      try { await client.query('ROLLBACK'); } catch (rbErr) { /* ignore */ }
      console.error('Error purchasing artifact (atomic):', error);
      return { success: false, error: error.message };
    } finally {
      client.release();
    }
  }

  /**
   * Get preview information for artifact
   */
  async previewArtifact(title) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      const result = await pool.query(
        'SELECT * FROM artifacts WHERE LOWER(title) LIKE LOWER($1) AND active = true LIMIT 1',
        [`%${title}%`]
      );

      const artifact = result.rows[0];
      if (!artifact) {
        return { success: false, error: `Could not find "${title}" in the marketplace` };
      }

      return {
        success: true,
        artifact: {
          id: artifact.id,
          title: artifact.title,
          slug: artifact.slug,
          description: artifact.description,
          category: artifact.category,
          price: parseFloat(artifact.solar_amount_s || '0'),
          streamingUrl: artifact.streaming_url,
          previewUrl: artifact.preview_file_url,
          coverArt: artifact.cover_art_url,
          fileType: artifact.file_type,
          previewType: artifact.preview_type
        }
      };

    } catch (error) {
      console.error('Error previewing artifact:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Check wallet balance
   */
  async checkWalletBalance(memberId) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      const result = await pool.query(
        'SELECT total_solar, total_dollars, name, joined_date FROM members WHERE id = $1',
        [memberId]
      );

      const member = result.rows[0];
      if (!member) {
        return { success: false, error: 'Member not found' };
      }

      return {
        success: true,
        balance: {
          solar: parseFloat(member.total_solar || '0'),
          dollars: parseFloat(member.total_dollars || '0'),
          name: member.name,
          memberSince: member.joined_date
        }
      };

    } catch (error) {
      console.error('Error checking balance:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * List marketplace items with filters
   */
  async listMarketplaceItems(category = 'all', maxPrice = null, limit = 10) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      let query = 'SELECT * FROM artifacts WHERE active = true';
      const params = [];
      let paramIndex = 1;

      // Category filter
      if (category && category !== 'all') {
        query += ` AND category = $${paramIndex}`;
        params.push(category);
        paramIndex++;
      }

      // Price filter
      if (maxPrice !== null && maxPrice !== undefined) {
        query += ` AND CAST(solar_amount_s AS DECIMAL) <= $${paramIndex}`;
        params.push(maxPrice);
        paramIndex++;
      }

      // Order by price and limit
      query += ` ORDER BY CAST(solar_amount_s AS DECIMAL) ASC LIMIT $${paramIndex}`;
      params.push(limit);

      const result = await pool.query(query, params);

      const items = result.rows.map(artifact => ({
        id: artifact.id,
        title: artifact.title,
        slug: artifact.slug,
        description: artifact.description,
        category: artifact.category,
        price: parseFloat(artifact.solar_amount_s || '0'),
        fileType: artifact.file_type,
        coverArt: artifact.cover_art_url,
        streamingUrl: artifact.streaming_url
      }));

      return {
        success: true,
        items: items,
        count: items.length,
        filters: {
          category: category,
          maxPrice: maxPrice,
          limit: limit
        }
      };

    } catch (error) {
      console.error('Error listing marketplace items:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Search marketplace artifacts by keyword, title, description, or tags
   */
  async searchMarketplace(query, category = 'all', limit = 10) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      const searchTerm = `%${query}%`;
      let sqlQuery = `SELECT id, title, slug, description, category, solar_amount_s, file_type, 
                              cover_art_url, streaming_url, search_tags, creator_name, creator_username
                       FROM artifacts WHERE active = true 
                       AND (LOWER(title) LIKE LOWER($1) 
                            OR LOWER(description) LIKE LOWER($1) 
                            OR LOWER(COALESCE(array_to_string(search_tags, ' '), '')) LIKE LOWER($1))`;
      const params = [searchTerm];
      let paramIndex = 2;

      if (category && category !== 'all') {
        sqlQuery += ` AND LOWER(category) = LOWER($${paramIndex})`;
        params.push(category);
        paramIndex++;
      }

      sqlQuery += ` ORDER BY CASE WHEN LOWER(title) LIKE LOWER($1) THEN 0 ELSE 1 END, created_at DESC LIMIT $${paramIndex}`;
      params.push(limit);

      const result = await pool.query(sqlQuery, params);

      const items = result.rows.map(artifact => ({
        id: artifact.id,
        title: artifact.title,
        slug: artifact.slug,
        description: (artifact.description || '').substring(0, 200),
        category: artifact.category,
        price: parseFloat(artifact.solar_amount_s || '0'),
        fileType: artifact.file_type,
        coverArt: artifact.cover_art_url,
        streamingUrl: artifact.streaming_url,
        tags: artifact.search_tags || [],
        creatorName: artifact.creator_name || artifact.creator_username || null
      }));

      return {
        success: true,
        query: query,
        items: items,
        count: items.length,
        message: items.length > 0 ? `Found ${items.length} results for "${query}"` : `No results found for "${query}" in the marketplace`
      };

    } catch (error) {
      console.error('Error searching marketplace:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Price an artifact using kWh energy assessment (Identify Anything)
   * Solar Standard: 1 Solar = 4,913 kWh
   * Pricing is based on estimated energy to create, store, and distribute the artifact
   */
  async priceArtifact(fileType, fileSizeMB = 1, durationSeconds = 0, description = '') {
    try {
      // Validate inputs
      if (!fileType || !['music', 'video', 'art', 'document', 'other'].includes(fileType)) {
        return { success: false, error: 'Invalid file type. Must be: music, video, art, document, or other' };
      }
      
      // Solar Standard: 1 Solar = 4,913 kWh (renewable energy equivalent)
      const KWH_PER_SOLAR = 4913;
      
      // Base energy calculations based on file type
      let estimatedKwh = 0;
      let reasoning = '';
      
      const baseStorageEnergy = (fileSizeMB || 1) * 0.0001; // 0.0001 kWh per MB storage
      const baseDistributionEnergy = 0.001; // Base distribution energy
      
      switch (fileType) {
        case 'music':
          const minutes = (durationSeconds || 180) / 60;
          const recordingEnergy = minutes * 0.05; // 0.05 kWh per minute of recording
          const productionEnergy = minutes * 0.02; // 0.02 kWh per minute of production
          estimatedKwh = recordingEnergy + productionEnergy + baseStorageEnergy + baseDistributionEnergy;
          reasoning = `Music: Recording (${recordingEnergy.toFixed(4)} kWh) + Production (${productionEnergy.toFixed(4)} kWh) + Storage (${baseStorageEnergy.toFixed(4)} kWh)`;
          break;
          
        case 'video':
          const videoMinutes = (durationSeconds || 300) / 60;
          const filmingEnergy = videoMinutes * 0.15;
          const editingEnergy = videoMinutes * 0.08;
          const renderingEnergy = videoMinutes * 0.12;
          estimatedKwh = filmingEnergy + editingEnergy + renderingEnergy + baseStorageEnergy + baseDistributionEnergy;
          reasoning = `Video: Filming (${filmingEnergy.toFixed(4)} kWh) + Editing (${editingEnergy.toFixed(4)} kWh) + Rendering (${renderingEnergy.toFixed(4)} kWh)`;
          break;
          
        case 'art':
          const creationEnergy = 0.05;
          const processingEnergy = (fileSizeMB || 1) * 0.001;
          estimatedKwh = creationEnergy + processingEnergy + baseStorageEnergy + baseDistributionEnergy;
          reasoning = `Digital art: Creation (${creationEnergy.toFixed(4)} kWh) + Processing (${processingEnergy.toFixed(4)} kWh)`;
          break;
          
        case 'document':
          const writingEnergy = 0.02;
          const formattingEnergy = 0.005;
          estimatedKwh = writingEnergy + formattingEnergy + baseStorageEnergy + baseDistributionEnergy;
          reasoning = `Document: Writing (${writingEnergy.toFixed(4)} kWh) + Formatting (${formattingEnergy.toFixed(4)} kWh)`;
          break;
          
        default:
          estimatedKwh = baseStorageEnergy + baseDistributionEnergy + 0.01;
          reasoning = `Generic file: Base energy estimate`;
      }
      
      // Convert kWh to Solar
      const solarPrice = estimatedKwh / KWH_PER_SOLAR;
      
      return {
        success: true,
        pricing: {
          estimatedKwh: estimatedKwh.toFixed(6),
          solarPrice: solarPrice.toFixed(6),
          reasoning: reasoning,
          fileType: fileType,
          kwhPerSolar: KWH_PER_SOLAR
        }
      };
      
    } catch (error) {
      console.error('Error pricing artifact:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * List an artifact for sale on the marketplace
   * Creates an active listing that can be purchased immediately
   */
  async listArtifactForSale(title, description, category, solarPrice, filePath, memberId) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      // Validate required fields
      if (!title || title.trim().length === 0) {
        return { success: false, error: 'Title is required' };
      }
      if (!category || !['music', 'video', 'art', 'document', 'education'].includes(category)) {
        return { success: false, error: 'Category must be: music, video, art, document, or education' };
      }
      if (!solarPrice || solarPrice <= 0) {
        return { success: false, error: 'Price must be greater than 0' };
      }

      // Get member info
      const memberResult = await pool.query(
        'SELECT name, email FROM members WHERE id = $1',
        [memberId]
      );
      const member = memberResult.rows[0];
      
      if (!member) {
        return { success: false, error: 'Member not found' };
      }

      // Generate slug from title
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const uniqueSlug = `${slug}-${Date.now()}`;

      // Calculate kWh equivalent (1 Solar = 4,913 kWh)
      const kwhEquivalent = solarPrice * 4913;

      // Insert artifact
      const result = await pool.query(
        `INSERT INTO artifacts (
          title, slug, description, category, solar_amount_s, kwh_equivalent,
          creator_email, active, created_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, true, NOW())
        RETURNING id, title, slug, solar_amount_s`,
        [title, uniqueSlug, description || '', category, solarPrice.toString(), kwhEquivalent, member.email]
      );

      const artifact = result.rows[0];

      // Log the listing transaction
      await pool.query(
        `INSERT INTO transactions (user_id, type, amount, currency, status, description, metadata, completed_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [
          memberId.toString(),
          'artifact_listed',
          0,
          'SOLAR',
          'completed',
          `Listed for sale: ${title}`,
          JSON.stringify({
            artifactId: artifact.id,
            artifactTitle: title,
            solarPrice: solarPrice
          })
        ]
      );

      return {
        success: true,
        artifact: {
          id: artifact.id,
          title: artifact.title,
          slug: artifact.slug,
          price: solarPrice,
          category: category
        },
        message: `Successfully listed "${title}" for ${solarPrice} Solar`
      };

    } catch (error) {
      console.error('Error listing artifact for sale:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Get user's transaction history (ledger)
   */
  async getTransactionHistory(memberId, limit = 10) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      const result = await pool.query(
        `SELECT id, type, amount, currency, status, description, metadata, completed_at
         FROM transactions 
         WHERE user_id = $1 
         ORDER BY completed_at DESC 
         LIMIT $2`,
        [memberId.toString(), limit]
      );

      const transactions = result.rows.map(tx => ({
        id: tx.id,
        type: tx.type,
        amount: parseFloat(tx.amount || 0),
        currency: tx.currency,
        status: tx.status,
        description: tx.description,
        details: tx.metadata,
        date: tx.completed_at
      }));

      return {
        success: true,
        transactions: transactions,
        count: transactions.length,
        message: transactions.length > 0 
          ? `Found ${transactions.length} recent transactions`
          : 'No transactions found'
      };

    } catch (error) {
      console.error('Error getting transaction history:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Create and upload a new artifact
   * This creates a placeholder entry for the artifact. The actual file upload
   * is handled separately through the marketplace upload UI.
   * 
   * Agent workflow:
   * 1. User asks "Create artifact called X"
   * 2. Kid Solar creates DB entry with metadata (pending status)
   * 3. User then uploads file through marketplace UI
   * 4. File upload links to the created entry
   */
  async createArtifact(title, description, category, tags, suggestedPrice, memberId, fileData = null) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      // Validate required fields
      if (!title || title.trim().length === 0) {
        return { success: false, error: 'Title is required' };
      }
      if (!category || !['music', 'video', 'art', 'document', 'education'].includes(category)) {
        return { success: false, error: 'Category must be: music, video, art, document, or education' };
      }

      // Get member info
      const memberResult = await pool.query(
        'SELECT name, email FROM members WHERE id = $1',
        [memberId]
      );
      const member = memberResult.rows[0];
      
      if (!member) {
        return { success: false, error: 'Member not found' };
      }

      // Calculate price if not suggested (uses kWh energy assessment)
      let finalPrice = suggestedPrice;
      if (!finalPrice) {
        const pricingResult = await this.priceArtifact(category, 1, 180, description);
        finalPrice = parseFloat(pricingResult.pricing?.solarPrice || 0.001);
      }

      // Generate slug
      const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const uniqueSlug = `${slug}-${Date.now()}`;

      // Calculate kWh equivalent
      const kwhEquivalent = finalPrice * 4913;

      // Insert artifact (pending review)
      const result = await pool.query(
        `INSERT INTO artifacts (
          title, slug, description, category, solar_amount_s, kwh_equivalent,
          creator_email, active, created_at, tags
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, false, NOW(), $8)
        RETURNING id, title, slug, solar_amount_s`,
        [
          title, 
          uniqueSlug, 
          description || '', 
          category, 
          finalPrice.toString(), 
          kwhEquivalent, 
          member.email,
          JSON.stringify(tags || [])
        ]
      );

      const artifact = result.rows[0];

      // Log creation transaction
      await pool.query(
        `INSERT INTO transactions (user_id, type, amount, currency, status, description, metadata, completed_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [
          memberId.toString(),
          'artifact_created',
          0,
          'SOLAR',
          'pending',
          `Created artifact: ${title}`,
          JSON.stringify({
            artifactId: artifact.id,
            artifactTitle: title,
            solarPrice: finalPrice,
            status: 'pending_review'
          })
        ]
      );

      return {
        success: true,
        artifact: {
          id: artifact.id,
          title: artifact.title,
          slug: artifact.slug,
          price: finalPrice,
          category: category,
          status: 'pending_review'
        },
        message: `Created "${title}" (pending review). Suggested price: ${finalPrice.toFixed(6)} Solar`,
        nextStep: 'Upload your file through the marketplace to complete the listing'
      };

    } catch (error) {
      console.error('Error creating artifact:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Process image with GPT-4o Vision
   */
  async processImageWithVision(imageData, prompt, conversationHistory = []) {
    try {
      let base64Image;
      
      if (Buffer.isBuffer(imageData)) {
        base64Image = imageData.toString('base64');
      } else if (typeof imageData === 'string' && imageData.startsWith('data:')) {
        base64Image = imageData.split(',')[1];
      } else if (typeof imageData === 'string') {
        base64Image = imageData;
      } else {
        throw new Error('Invalid image data format');
      }

      const imageUrl = `data:image/jpeg;base64,${base64Image}`;

      const messages = [
        { role: 'system', content: this.systemPrompt },
        ...conversationHistory,
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt || 'What do you see in this image?' },
            { type: 'image_url', image_url: { url: imageUrl } }
          ]
        }
      ];

      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: messages,
        max_tokens: 300
      });

      return {
        text: completion.choices[0].message.content,
        intent: 'image_analysis'
      };

    } catch (error) {
      console.error('Error processing image:', error);
      throw new Error(`Image processing failed: ${error.message}`);
    }
  }

  /**
   * Process file text extraction
   */
  async processFileText(fileData, fileName, prompt, conversationHistory = []) {
    try {
      const ext = path.extname(fileName).toLowerCase();
      let extractedText = '';

      if (ext === '.txt') {
        extractedText = Buffer.isBuffer(fileData) ? fileData.toString('utf-8') : fileData;
      } else if (ext === '.pdf') {
        return {
          text: "I can see you've uploaded a PDF document. PDF text extraction is coming soon! For now, please copy and paste the text you'd like me to analyze.",
          intent: 'file_upload'
        };
      } else if (ext === '.doc' || ext === '.docx') {
        return {
          text: "I can see you've uploaded a Word document. Document analysis is coming soon! For now, please copy and paste the text you'd like me to analyze.",
          intent: 'file_upload'
        };
      } else {
        throw new Error(`Unsupported file type: ${ext}`);
      }

      if (extractedText.length > 4000) {
        extractedText = extractedText.substring(0, 4000) + '... (truncated)';
      }

      const messages = [
        { role: 'system', content: this.systemPrompt },
        ...conversationHistory,
        {
          role: 'user',
          content: `${prompt || 'Please analyze this file content:'}\n\nFile: ${fileName}\n\nContent:\n${extractedText}`
        }
      ];

      const completion = await this.openai.chat.completions.create({
        model: this.model,
        messages: messages,
        max_tokens: 300
      });

      return {
        text: completion.choices[0].message.content,
        intent: 'file_analysis'
      };

    } catch (error) {
      console.error('Error processing file:', error);
      throw new Error(`File processing failed: ${error.message}`);
    }
  }

  /**
   * Convert text to speech using OpenAI TTS
   */
  async textToSpeech(text) {
    try {
      const mp3 = await this.openai.audio.speech.create({
        model: 'tts-1',
        voice: this.ttsVoice,
        input: text,
        speed: 1.0
      });

      const buffer = Buffer.from(await mp3.arrayBuffer());
      return buffer;

    } catch (error) {
      console.error('Error generating speech:', error);
      throw new Error(`TTS failed: ${error.message}`);
    }
  }

  /**
   * Get wallet data for member
   */
  async getWalletData(memberId) {
    try {
      const pool = getSharedPool();
      
      if (!pool) {
        console.warn('Database pool unavailable');
        return {
          balance: 0,
          name: 'Member',
          recentTransactions: [],
          energyListings: []
        };
      }
      
      const balanceResult = await pool.query(
        'SELECT total_solar, name, joined_date FROM members WHERE id = $1',
        [memberId]
      );

      // Get wallet_id for this member to fetch transactions
      const walletResult = await pool.query(
        'SELECT id FROM wallets WHERE member_id = $1',
        [memberId]
      );
      
      const walletId = walletResult.rows[0]?.id;
      
      let recentTransactions = [];
      if (walletId) {
        const transactionsResult = await pool.query(
          'SELECT * FROM transactions WHERE wallet_id = $1 ORDER BY created_at DESC LIMIT 5',
          [walletId]
        );
        recentTransactions = transactionsResult.rows;
      }

      return {
        balance: parseFloat(balanceResult.rows[0]?.total_solar || '0'),
        name: balanceResult.rows[0]?.name || 'Member',
        memberSince: balanceResult.rows[0]?.joined_date,
        recentTransactions: recentTransactions,
        energyListings: []
      };

    } catch (error) {
      console.error('Error fetching wallet data:', error);
      return {
        balance: 0,
        name: 'Member',
        recentTransactions: [],
        energyListings: []
      };
    }
  }

  // ========================================
  // MCP ORCHESTRATION LAYER
  // Kid Solar Agent Action Controls
  // ========================================

  getSpecialistAgent(category) {
    const SPECIALISTS = {
      'Computronium': { code: '01', name: 'Alpha', icon: '🅰️', backup: '17' },
      'Culture': { code: '02', name: 'Bravo', icon: '🅱️', backup: '20' },
      'Basic Needs': { code: '03', name: 'Charlie', icon: '©️' },
      'Rent': { code: '04', name: 'Delta', icon: '🔺' },
      'Energy': { code: '05', name: 'Echo', icon: '📡', backup: '18' },
      'Music': { code: '06', name: 'Foxtrot', icon: '🦊' },
      'Video': { code: '07', name: 'Golf', icon: '⛳' },
      'Art': { code: '08', name: 'Hotel', icon: '🏨' },
      'Photo': { code: '09', name: 'India', icon: '🇮🇳' },
      'Writing': { code: '10', name: 'Juliet', icon: '🌹' },
      'AI Tools': { code: '11', name: 'Kilo', icon: '⚖️', backup: '19' },
      'AI Create': { code: '12', name: 'Lima', icon: '🌿' },
      'Software': { code: '13', name: 'Nova', icon: '💫' },
      'Education': { code: '14', name: 'Orion', icon: '🎓' },
      'Games': { code: '15', name: 'Pulse', icon: '💓' },
      'Utilities': { code: '16', name: 'Quasar', icon: '✨' }
    };
    return SPECIALISTS[category] || null;
  }

  async agentRecommend(category, maxPrice, limit, memberId) {
    const pool = getSharedPool();
    if (!pool) return { success: false, error: 'Database unavailable' };

    try {
      const specialist = this.getSpecialistAgent(category);
      if (!specialist) {
        return { success: false, error: `No specialist agent found for category: ${category}` };
      }

      const agentUsername = `agent_eco_${specialist.code}`;

      const agentResult = await pool.query(
        'SELECT id, total_solar FROM members WHERE username = $1',
        [agentUsername]
      );
      const agentMember = agentResult.rows[0];

      let query = `SELECT a.id, a.title, a.slug, a.description, a.category, a.solar_amount_s, a.file_type, a.cover_art_url, a.streaming_url, a.created_at
                   FROM artifacts a
                   WHERE a.active = true AND a.category = $1
                   AND a.id NOT IN (SELECT artifact_id FROM artifact_copies WHERE owner_id = $2)`;
      const params = [category, memberId];
      let paramIdx = 3;

      if (maxPrice !== null && maxPrice !== undefined) {
        query += ` AND CAST(a.solar_amount_s AS DECIMAL) <= $${paramIdx}`;
        params.push(maxPrice);
        paramIdx++;
      }

      query += ` ORDER BY a.created_at DESC LIMIT $${paramIdx}`;
      params.push(limit);

      const result = await pool.query(query, params);

      const items = result.rows.map(a => ({
        id: a.id,
        title: a.title,
        slug: a.slug,
        description: a.description,
        category: a.category,
        price: parseFloat(a.solar_amount_s || '0'),
        fileType: a.file_type,
        coverArt: a.cover_art_url,
        streamingUrl: a.streaming_url
      }));

      let createdByAgent = 0;
      if (agentMember) {
        const createdResult = await pool.query(
          `SELECT COUNT(*) as cnt FROM artifacts WHERE creator_id = $1 AND category = $2 AND active = true`,
          [agentMember.id, category]
        );
        createdByAgent = parseInt(createdResult.rows[0]?.cnt || '0');
      }

      return {
        success: true,
        specialist: {
          code: specialist.code,
          name: `Agent ${specialist.name}`,
          icon: specialist.icon,
          category: category,
          itemsCreated: createdByAgent,
          balance: agentMember ? parseFloat(agentMember.total_solar || '0') : 0
        },
        recommendations: items,
        count: items.length,
        message: items.length > 0
          ? `Agent ${specialist.name} ${specialist.icon} recommends ${items.length} ${category} items`
          : `Agent ${specialist.name} found no available ${category} items matching your criteria`
      };

    } catch (error) {
      console.error('Error in agent recommendation:', error);
      return { success: false, error: error.message };
    }
  }

  async agentBatchOrder(orders, memberId) {
    const pool = getSharedPool();
    if (!pool) return { success: false, error: 'Database unavailable' };

    const crypto = require('crypto');

    try {
      const memberResult = await pool.query(
        'SELECT id, total_solar, name FROM members WHERE id = $1',
        [memberId]
      );
      const member = memberResult.rows[0];
      if (!member) return { success: false, error: 'Member not found' };

      let currentBalance = parseFloat(member.total_solar || '0');
      const results = [];
      let totalSpent = 0;
      let totalPurchased = 0;
      let totalFailed = 0;

      for (const order of orders) {
        const specialist = this.getSpecialistAgent(order.category);
        const orderResult = {
          category: order.category,
          specialist: specialist ? `Agent ${specialist.name} ${specialist.icon}` : 'Direct',
          requested: order.quantity,
          purchased: [],
          errors: []
        };

        let query = `SELECT a.id, a.title, a.slug, a.solar_amount_s, a.creator_id, a.category
                     FROM artifacts a
                     WHERE a.active = true AND a.category = $1
                     AND a.id NOT IN (SELECT artifact_id FROM artifact_copies WHERE owner_id = $2)`;
        const params = [order.category, memberId];
        let paramIdx = 3;

        if (order.maxPrice) {
          query += ` AND CAST(a.solar_amount_s AS DECIMAL) <= $${paramIdx}`;
          params.push(order.maxPrice);
          paramIdx++;
        }

        query += ` ORDER BY CAST(a.solar_amount_s AS DECIMAL) ASC LIMIT $${paramIdx}`;
        params.push(order.quantity);

        const itemsResult = await pool.query(query, params);

        if (itemsResult.rows.length === 0) {
          orderResult.errors.push(`No available ${order.category} items found`);
          results.push(orderResult);
          continue;
        }

        for (const artifact of itemsResult.rows) {
          const artPrice = parseFloat(artifact.solar_amount_s) || 0.01;

          if (currentBalance < artPrice) {
            orderResult.errors.push(`Insufficient balance for "${artifact.title}" (${artPrice} Solar)`);
            totalFailed++;
            continue;
          }

          const client = await pool.connect();
          try {
            const txId = crypto.randomUUID();
            const creatorIdNum = parseInt(artifact.creator_id) || 0;
            const creatorIdStr = String(artifact.creator_id);

            await client.query('BEGIN');

            const newBalance = currentBalance - artPrice;
            await client.query('UPDATE members SET total_solar = $1 WHERE id = $2', [String(newBalance), memberId]);

            await client.query(
              `INSERT INTO marketplace_ledger (transaction_id, entry_type, account_id, account_type, amount, balance_after, reference_type, reference_id, description)
               VALUES ($1, 'debit', $2, 'user', $3, $4, 'purchase', $5, $6)`,
              [txId, String(memberId), String(artPrice), String(newBalance), artifact.id, `MCP Purchase: ${artifact.title}`]
            );

            const sellerRow = await client.query(
              'SELECT id, username, total_solar FROM members WHERE id = $1 OR username = $2 LIMIT 1',
              [creatorIdNum, creatorIdStr]
            );

            if (sellerRow.rows.length > 0) {
              const seller = sellerRow.rows[0];
              const sellerNewBal = (parseFloat(seller.total_solar) || 0) + artPrice;
              await client.query('UPDATE members SET total_solar = $1 WHERE id = $2', [String(sellerNewBal), seller.id]);
              await client.query(
                `INSERT INTO marketplace_ledger (transaction_id, entry_type, account_id, account_type, amount, balance_after, reference_type, reference_id, description)
                 VALUES ($1, 'credit', $2, 'creator', $3, $4, 'purchase', $5, $6)`,
                [txId, String(seller.id), String(artPrice), String(sellerNewBal), artifact.id, `MCP Sale: ${artifact.title}`]
              );
            }

            await client.query(
              `INSERT INTO artifact_copies (artifact_id, owner_id, purchase_transaction_id, acquired_method, solar_paid) VALUES ($1, $2, $3, 'purchase', $4)`,
              [artifact.id, memberId, txId, String(artPrice)]
            );

            await client.query(
              `INSERT INTO transactions (user_id, type, amount, currency, status, description, metadata, completed_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
              [
                memberId.toString(), 'solar_spend', artPrice, 'SOLAR', 'completed',
                `MCP Purchase: ${artifact.title}`,
                JSON.stringify({ artifactId: artifact.id, artifactTitle: artifact.title, category: artifact.category, solarPrice: artPrice, txId: txId, via: 'kid_solar_mcp', specialist: order.category })
              ]
            );

            await client.query('COMMIT');

            currentBalance = newBalance;
            totalSpent += artPrice;
            totalPurchased++;
            orderResult.purchased.push({
              title: artifact.title,
              price: artPrice,
              txId: txId
            });

          } catch (err) {
            try { await client.query('ROLLBACK'); } catch (rbErr) { /* ignore */ }
            orderResult.errors.push(`Failed to purchase "${artifact.title}": ${err.message}`);
            totalFailed++;
          } finally {
            client.release();
          }
        }

        results.push(orderResult);
      }

      return {
        success: true,
        orchestrator: 'Kid Solar 🌞 (MCP)',
        summary: {
          totalOrders: orders.length,
          totalPurchased: totalPurchased,
          totalFailed: totalFailed,
          totalSpent: parseFloat(totalSpent.toFixed(6)),
          startingBalance: parseFloat(member.total_solar || '0'),
          remainingBalance: parseFloat(currentBalance.toFixed(6))
        },
        orderResults: results,
        message: `MCP batch order complete: ${totalPurchased} items purchased across ${orders.length} categories for ${totalSpent.toFixed(6)} Solar`
      };

    } catch (error) {
      console.error('Error in batch order:', error);
      return { success: false, error: error.message };
    }
  }

  async agentNetworkStatus(agentCode = null) {
    const pool = getSharedPool();
    if (!pool) return { success: false, error: 'Database unavailable' };

    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      if (agentCode) {
        const username = `agent_eco_${agentCode}`;
        const agentResult = await pool.query(
          `SELECT m.id, m.username, m.name, m.total_solar, m.is_agent, m.joined_date
           FROM members m WHERE m.username = $1`,
          [username]
        );

        if (agentResult.rows.length === 0) {
          return { success: false, error: `Agent ${agentCode} not found` };
        }

        const agent = agentResult.rows[0];

        const createdToday = await pool.query(
          `SELECT id, title, category, solar_amount_s FROM artifacts WHERE creator_id = $1 AND created_at >= $2 ORDER BY created_at DESC`,
          [agent.id, today.toISOString()]
        );

        const purchasesToday = await pool.query(
          `SELECT ml.transaction_id, ml.amount, ml.description, ml.created_at
           FROM marketplace_ledger ml
           WHERE ml.account_id = $1 AND ml.entry_type = 'debit' AND ml.created_at >= $2
           ORDER BY ml.created_at DESC`,
          [String(agent.id), today.toISOString()]
        );

        const totalCreated = await pool.query(
          `SELECT COUNT(*) as cnt FROM artifacts WHERE creator_id = $1 AND active = true`,
          [agent.id]
        );

        return {
          success: true,
          agent: {
            code: agentCode,
            username: agent.username,
            displayName: agent.name,
            balance: parseFloat(agent.total_solar || '0'),
            isAgent: agent.is_agent,
            memberSince: agent.joined_date,
            totalArtifactsCreated: parseInt(totalCreated.rows[0]?.cnt || '0'),
            todayActivity: {
              artifactsCreated: createdToday.rows.map(a => ({
                title: a.title,
                category: a.category,
                price: parseFloat(a.solar_amount_s || '0')
              })),
              purchases: purchasesToday.rows.map(p => ({
                description: p.description,
                amount: parseFloat(p.amount || '0')
              }))
            }
          }
        };
      }

      const allAgents = await pool.query(
        `SELECT m.id, m.username, m.name, m.total_solar, m.joined_date
         FROM members m
         WHERE m.is_agent = true
         ORDER BY m.username ASC`
      );

      const agentList = [];
      for (const agent of allAgents.rows) {
        const code = agent.username.replace('agent_eco_', '');
        const specialist = this.getSpecialistAgent(
          code === 'ks' ? 'Orchestrator' : null
        );

        const todayCreated = await pool.query(
          `SELECT COUNT(*) as cnt FROM artifacts WHERE creator_id = $1 AND created_at >= $2`,
          [agent.id, today.toISOString()]
        );

        const todayPurchases = await pool.query(
          `SELECT COUNT(*) as cnt FROM marketplace_ledger WHERE account_id = $1 AND entry_type = 'debit' AND created_at >= $2`,
          [String(agent.id), today.toISOString()]
        );

        agentList.push({
          code: code,
          name: agent.name,
          balance: parseFloat(agent.total_solar || '0'),
          todayCreated: parseInt(todayCreated.rows[0]?.cnt || '0'),
          todayPurchased: parseInt(todayPurchases.rows[0]?.cnt || '0')
        });
      }

      return {
        success: true,
        network: {
          totalAgents: agentList.length,
          agents: agentList,
          kidSolarStatus: 'online',
          mcpProtocol: 'v1.0',
          lastDailyRun: '4:00 AM UTC'
        },
        message: `TC-S Agent Network: ${agentList.length} agents online`
      };

    } catch (error) {
      console.error('Error getting agent network status:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Detect user intent from text
   */
  detectIntent(text) {
    const lower = text.toLowerCase();
    
    if (lower.includes('balance') || lower.includes('how much')) return 'check_balance';
    if (lower.includes('transaction') || lower.includes('history')) return 'check_transactions';
    if (lower.includes('energy') || lower.includes('rec') || lower.includes('ppa')) return 'check_energy';
    if (lower.includes('list') || lower.includes('sell')) return 'list_energy';
    if (lower.includes('buy') || lower.includes('purchase')) return 'buy_artifact';
    if (lower.includes('preview') || lower.includes('play') || lower.includes('stream')) return 'preview_artifact';
    if (lower.includes('upload') || lower.includes('submit')) return 'upload_artifact';
    if (lower.includes('my upload') || lower.includes('my artifact')) return 'check_my_uploads';
    if (lower.includes('how to upload') || lower.includes('upload guide')) return 'upload_guidance';
    if (lower.includes('help') || lower.includes('what can')) return 'help';
    
    return 'general_query';
  }

  /**
   * Analyze artifact file for upload using Vision API
   */
  async analyzeArtifactForUpload(fileData, fileName, fileType) {
    try {
      if (!fileData || !fileData.buffer) {
        return {
          success: false,
          error: 'No file data provided for analysis'
        };
      }

      let analysisText = '';
      let category = 'uncategorized';
      let suggestedPrice = 0.001;

      if (fileType.startsWith('image/')) {
        const visionPrompt = `Analyze this image for marketplace upload. Provide:
1. Suggested title (creative and descriptive)
2. Detailed description (2-3 sentences)
3. Category (art/photo/design)
4. 3-5 relevant tags
5. Suggested pricing in Solar (0.001-0.01 range based on quality and complexity)

Format your response as JSON.`;

        const visionResult = await this.processImageWithVision(fileData.buffer, visionPrompt);
        analysisText = visionResult.text;
        
        const match = analysisText.match(/\{[\s\S]*\}/);
        if (match) {
          try {
            const parsed = JSON.parse(match[0]);
            return {
              success: true,
              suggestions: {
                title: parsed.title || fileName.replace(/\.[^/.]+$/, ''),
                description: parsed.description || 'High-quality artwork',
                category: parsed.category || 'art',
                tags: parsed.tags || [],
                price: parsed.price || 0.005
              },
              fileInfo: {
                name: fileName,
                type: fileType,
                category: 'image'
              }
            };
          } catch (e) {
            console.warn('Failed to parse Vision JSON, using text analysis');
          }
        }
        
        category = 'art';
        suggestedPrice = 0.005;

      } else if (fileType.startsWith('audio/')) {
        category = 'music';
        suggestedPrice = 0.002;
        analysisText = 'Audio file detected. Suggested category: Music';

      } else if (fileType.startsWith('video/')) {
        category = 'video';
        suggestedPrice = 0.01;
        analysisText = 'Video file detected. Suggested category: Video';

      } else {
        category = 'document';
        suggestedPrice = 0.001;
        analysisText = 'Document file detected';
      }

      const cleanTitle = fileName.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');

      return {
        success: true,
        suggestions: {
          title: cleanTitle.charAt(0).toUpperCase() + cleanTitle.slice(1),
          description: `${category.charAt(0).toUpperCase() + category.slice(1)} file: ${fileName}`,
          category: category,
          tags: [category, 'upload'],
          price: suggestedPrice
        },
        fileInfo: {
          name: fileName,
          type: fileType,
          category: category
        },
        analysis: analysisText
      };

    } catch (error) {
      console.error('Error analyzing artifact:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Provide upload guidance
   */
  async getUploadGuidance(fileType = null) {
    const guidance = {
      success: true,
      general: {
        steps: [
          'Go to the Upload tab in the marketplace',
          'Select your file (drag & drop or browse)',
          'Add a catchy title and description',
          'Choose the right category',
          'Set your Solar price (or let AI suggest)',
          'Submit for review'
        ],
        tips: [
          'Use clear, descriptive titles',
          'Add relevant tags for better discovery',
          'High-quality files get more attention',
          'Pricing is based on file size and content value'
        ]
      },
      limits: {
        music: { maxSize: '50MB', formats: 'MP3, WAV, FLAC, OGG', suggestedPrice: '0.001-0.005 Solar' },
        video: { maxSize: '500MB', formats: 'MP4, WEBM, MOV', suggestedPrice: '0.005-0.02 Solar' },
        art: { maxSize: '25MB', formats: 'JPG, PNG, GIF, WEBP, SVG', suggestedPrice: '0.002-0.01 Solar' },
        document: { maxSize: '5MB', formats: 'PDF, TXT, DOC, DOCX', suggestedPrice: '0.001-0.003 Solar' }
      }
    };

    if (fileType) {
      const type = fileType.toLowerCase();
      if (guidance.limits[type]) {
        guidance.specific = guidance.limits[type];
      }
    }

    return guidance;
  }

  /**
   * Check user's uploads and their status
   */
  async checkMyUploads(memberId) {
    const pool = getSharedPool();
    if (!pool) {
      return { success: false, error: 'Database unavailable' };
    }

    try {
      const result = await pool.query(
        `SELECT id, title, category, solar_amount_s, active, created_at, processing_status
         FROM artifacts 
         WHERE creator_id = $1 
         ORDER BY created_at DESC 
         LIMIT 20`,
        [memberId.toString()]
      );

      const uploads = result.rows.map(artifact => ({
        id: artifact.id,
        title: artifact.title,
        category: artifact.category,
        price: parseFloat(artifact.solar_amount_s || '0'),
        status: artifact.active ? 'approved' : 'pending review',
        processingStatus: artifact.processing_status || 'completed',
        uploadedAt: artifact.created_at
      }));

      const stats = {
        total: uploads.length,
        approved: uploads.filter(u => u.status === 'approved').length,
        pending: uploads.filter(u => u.status === 'pending review').length
      };

      return {
        success: true,
        uploads: uploads,
        stats: stats
      };

    } catch (error) {
      console.error('Error checking uploads:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Complete voice interaction: audio in, audio out
   */
  async handleVoiceInteraction(audioBuffer, memberId, memberContext, audioFormat = 'webm') {
    try {
      const transcribedText = await this.transcribeAudio(audioBuffer, audioFormat);
      console.log(`🎤 Kid Solar heard: "${transcribedText}"`);

      const response = await this.processVoiceCommand(transcribedText, memberId, memberContext);
      console.log(`💬 Kid Solar responds: "${response.text}"`);

      const audioResponse = await this.textToSpeech(response.text);

      return {
        transcription: transcribedText,
        responseText: response.text,
        responseAudio: audioResponse,
        intent: response.intent,
        walletData: response.data,
        functionCalled: response.functionCalled,
        functionArgs: response.functionArgs
      };

    } catch (error) {
      console.error('Error in voice interaction:', error);
      
      const errorText = "I'm having trouble understanding. Could you please try again?";
      const errorAudio = await this.textToSpeech(errorText);
      
      return {
        transcription: '',
        responseText: errorText,
        responseAudio: errorAudio,
        intent: 'error',
        error: error.message
      };
    }
  }
}

module.exports = KidSolarVoice;
