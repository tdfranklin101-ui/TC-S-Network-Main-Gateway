import { eq, desc, sql, and, or } from 'drizzle-orm';
import { db } from './db';
import { 
  members, distributionLogs, backupLogs, products, newsletterSubscriptions, contactMessages,
  progressions, entitlements, transactions, userProfiles, contentLibrary, users,
  artifacts, artifactCopies, marketplaceLedger, downloadTokens, wallets,
  marketItems, marketRequests, procurementRecommendations, procurementReviews,
  type Member, type InsertMember, type DistributionLog, type InsertDistributionLog, 
  type BackupLog, type InsertBackupLog, type Product, type InsertProduct,
  type NewsletterSubscription, type InsertNewsletterSubscription,
  type ContactMessage, type InsertContactMessage, type Progression, type InsertProgression,
  type Entitlement, type InsertEntitlement, type Transaction, type InsertTransaction,
  type UserProfile, type InsertUserProfile, type ContentLibrary, type InsertContentLibrary,
  type User, type InsertUser,
  type Artifact, type ArtifactCopy, type InsertArtifactCopy,
  type MarketplaceLedgerEntry, type InsertMarketplaceLedgerEntry,
  type DownloadToken, type InsertDownloadToken,
  type Wallet,
  type MarketItem, type InsertMarketItem,
  type MarketRequest, type InsertMarketRequest,
  type ProcurementRecommendation, type InsertProcurementRecommendation,
  type ProcurementReview, type InsertProcurementReview
} from '../shared/schema';
import fs from 'fs';
import path from 'path';
import session from 'express-session';
import connectPgSimple from 'connect-pg-simple';

const FOUNDATION_USERNAME = 'tcs_foundation';
const FOUNDATION_FEE_RATE = 0.05;

// Storage interface for member data and timer-gated progression
export interface IStorage {
  // Member operations
  getMembers(): Promise<Member[]>;
  getMember(id: number): Promise<Member | undefined>;
  getMemberByUsername(username: string): Promise<Member | undefined>;
  getMemberByEmail(email: string): Promise<Member | undefined>;
  createMember(data: InsertMember): Promise<Member>;
  updateMember(id: number, data: Partial<InsertMember>): Promise<Member | undefined>;
  deleteMember(id: number): Promise<boolean>;
  
  // Distribution operations
  createDistributionLog(data: InsertDistributionLog): Promise<DistributionLog>;
  getDistributionLogs(memberId?: number): Promise<DistributionLog[]>;
  getLastDistribution(memberId: number): Promise<DistributionLog | undefined>;
  
  // Backup operations
  createBackupLog(data: InsertBackupLog): Promise<BackupLog>;
  getBackupLogs(): Promise<BackupLog[]>;
  
  // Import/Export
  importMembersFromJson(filePath: string): Promise<{ success: boolean, imported: number, errors: any[] }>;
  exportMembersToJson(filePath: string): Promise<{ success: boolean, exported: number }>;
  
  // Migration assistance
  migrateFileBasedMembersToDatabase(membersList: any[]): Promise<{ success: boolean, migrated: number, errors: any[] }>;

  // User operations for timer-gated progression
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(data: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;
  updateUserCredentials(id: string, email: string, hashedPassword: string): Promise<User | undefined>;

  // User profile operations
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(data: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: string, data: Partial<InsertUserProfile>): Promise<UserProfile | undefined>;
  updateSolarBalance(userId: string, amount: number): Promise<UserProfile | undefined>;
  
  // Progression operations
  getProgression(userId: string | null, sessionId: string | null, contentType: string, contentId: string): Promise<Progression | undefined>;
  getUserProgressions(userId: string | null, sessionId: string | null): Promise<Progression[]>;
  createProgression(data: InsertProgression): Promise<Progression>;
  updateProgression(id: string, data: Partial<InsertProgression>): Promise<Progression | undefined>;
  startTimer(userId: string | null, sessionId: string | null, contentType: string, contentId: string, duration: number): Promise<Progression>;
  completeTimer(progressionId: string): Promise<Progression | undefined>;
  
  // Entitlement operations
  getEntitlement(userId: string | null, sessionId: string | null, contentType: string, contentId: string): Promise<Entitlement | undefined>;
  getUserEntitlements(userId: string | null, sessionId: string | null): Promise<Entitlement[]>;
  createEntitlement(data: InsertEntitlement): Promise<Entitlement>;
  revokeEntitlement(id: string): Promise<boolean>;
  
  // Transaction operations
  createTransaction(data: InsertTransaction): Promise<Transaction>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  updateTransactionStatus(id: string, status: string, completedAt?: Date): Promise<Transaction | undefined>;
  
  // Content library operations
  getContentLibrary(): Promise<ContentLibrary[]>;
  getContentItem(contentType: string, contentId: string): Promise<ContentLibrary | undefined>;
  createContentItem(data: InsertContentLibrary): Promise<ContentLibrary>;
  updateContentItem(id: string, data: Partial<InsertContentLibrary>): Promise<ContentLibrary | undefined>;
  
  // Composite operations for progression flow
  canAccessContent(userId: string | null, sessionId: string | null, contentType: string, contentId: string): Promise<{
    canAccess: boolean;
    accessType: 'locked' | 'timer_active' | 'timer_complete' | 'preview' | 'full';
    timeRemaining?: number;
    solarCost?: number;
    progression?: Progression;
    entitlement?: Entitlement;
    userBalance?: number;
  }>;
  unlockContentWithPayment(userId: string, contentType: string, contentId: string, solarCost: number): Promise<{
    success: boolean;
    entitlement?: Entitlement;
    transaction?: Transaction;
    error?: string;
  }>;

  // Unlock content with Solar tokens
  unlockWithSolar(userId: string, contentType: string, contentId: string): Promise<{
    success: boolean;
    entitlement?: Entitlement;
    transaction?: Transaction;
    newBalance?: number;
    error?: string;
    message?: string;
  }>;

  // Transfer session progressions to user account
  transferSessionProgressions(sessionId: string, userId: string): Promise<void>;

  // Product operations
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(data: InsertProduct): Promise<Product>;
  updateProduct(id: string, data: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Newsletter subscription operations  
  createNewsletterSubscription(data: InsertNewsletterSubscription): Promise<NewsletterSubscription>;
  getNewsletterSubscriptions(): Promise<NewsletterSubscription[]>;
  getNewsletterSubscriptionByEmail(email: string): Promise<NewsletterSubscription | undefined>;
  unsubscribeNewsletter(email: string): Promise<boolean>;

  // Contact message operations
  createContactMessage(data: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  getContactMessage(id: string): Promise<ContactMessage | undefined>;
  updateContactMessageStatus(id: string, status: string): Promise<ContactMessage | undefined>;

  // Solar accounts (legacy member system compatibility)
  getAllSolarAccounts(limit?: number, includeAnonymous?: boolean): Promise<Member[]>;
  createSolarAccount(data: { userId: string; isAnonymous: boolean; displayName: string }): Promise<Member>;
  
  // Solar balance operations (members.total_solar is single source of truth)
  getMemberSolarBalance(memberId: number): Promise<number>;
  updateMemberSolarBalance(memberId: number, newBalance: number): Promise<boolean>;

  // ============================================================
  // MARKETPLACE OPERATIONS - Artifact purchase and copy management
  // ============================================================
  
  // Artifact operations
  getArtifact(id: string): Promise<Artifact | undefined>;
  getArtifactBySlug(slug: string): Promise<Artifact | undefined>;
  getAvailableArtifacts(): Promise<Artifact[]>;
  
  // Artifact copy operations (ownership tracking)
  createArtifactCopy(data: InsertArtifactCopy): Promise<ArtifactCopy>;
  getUserArtifactCopies(userId: number): Promise<(ArtifactCopy & { artifact: Artifact })[]>;
  getArtifactCopy(userId: number, artifactId: string): Promise<ArtifactCopy | undefined>;
  
  // Download token operations
  createDownloadToken(data: InsertDownloadToken): Promise<DownloadToken>;
  getDownloadToken(token: string): Promise<DownloadToken | undefined>;
  incrementDownloadCount(tokenId: string): Promise<void>;
  
  // Marketplace ledger operations (double-entry accounting)
  createLedgerEntry(data: InsertMarketplaceLedgerEntry): Promise<MarketplaceLedgerEntry>;
  getLedgerEntriesByTransaction(transactionId: string): Promise<MarketplaceLedgerEntry[]>;
  getLedgerEntriesByAccount(accountId: string, limit?: number): Promise<MarketplaceLedgerEntry[]>;
  
  // Complete purchase flow (atomic transaction)
  purchaseArtifact(buyerId: number, artifactId: string): Promise<{
    success: boolean;
    copy?: ArtifactCopy;
    downloadToken?: DownloadToken;
    ledgerEntries?: MarketplaceLedgerEntry[];
    error?: string;
  }>;

  // ============================================================
  // WALLET OPERATIONS - For Replit Auth wallet claiming
  // ============================================================
  getWalletByEmail(email: string): Promise<Wallet | undefined>;
  getWalletByUserId(userId: string): Promise<Wallet | undefined>;
  linkWalletToUser(walletId: string, userId: string): Promise<Wallet | undefined>;
  createWallet(data: { userId: string; email?: string; balanceSolarS?: string; balanceRays?: number; promptCredits?: number }): Promise<Wallet>;
  
  // Upsert user for Replit Auth
  upsertUser(data: { id: string; email?: string | null; firstName?: string | null; lastName?: string | null; profileImageUrl?: string | null }): Promise<User>;
  
  // Session store for passport sessions
  sessionStore: any;

  // ============================================================
  // MARKETPLACE SEARCH & PROCUREMENT OPERATIONS
  // ============================================================
  
  // Market Items methods
  searchMarketItems(query: string, limit?: number): Promise<MarketItem[]>;
  getMarketItemById(id: string): Promise<MarketItem | undefined>;
  getMarketItemsByStatus(status: string): Promise<MarketItem[]>;
  createMarketItem(item: InsertMarketItem): Promise<MarketItem>;
  updateMarketItem(id: string, updates: Partial<InsertMarketItem>): Promise<MarketItem | undefined>;
  publishMarketItem(id: string): Promise<MarketItem | undefined>;

  // Market Requests methods
  createMarketRequest(request: InsertMarketRequest): Promise<MarketRequest>;
  getMarketRequestById(id: string): Promise<MarketRequest | undefined>;
  getMarketRequestsByStatus(status: string): Promise<MarketRequest[]>;
  updateMarketRequestStatus(id: string, status: string): Promise<MarketRequest | undefined>;

  // Procurement Recommendations methods
  createProcurementRecommendation(rec: InsertProcurementRecommendation): Promise<ProcurementRecommendation>;
  getRecommendationsByRequestId(requestId: string): Promise<ProcurementRecommendation[]>;

  // Procurement Reviews methods
  createProcurementReview(review: InsertProcurementReview): Promise<ProcurementReview>;
  getReviewByRequestId(requestId: string): Promise<ProcurementReview | undefined>;
}

// Implementation of the storage interface using Drizzle ORM
export class DatabaseStorage implements IStorage {
  // Session store for passport sessions
  sessionStore: any;

  constructor() {
    // Initialize session store with PostgreSQL
    const PgSession = connectPgSimple(session);
    this.sessionStore = new PgSession({
      conString: process.env.DATABASE_URL,
      tableName: 'session'
    });
  }
  // Member operations
  async getMembers(): Promise<Member[]> {
    return await db.select().from(members).orderBy(members.id);
  }
  
  async getMember(id: number): Promise<Member | undefined> {
    const result = await db.select().from(members).where(eq(members.id, id));
    return result[0];
  }
  
  async getMemberByUsername(username: string): Promise<Member | undefined> {
    const result = await db.select().from(members).where(eq(members.username, username));
    return result[0];
  }
  
  async getMemberByEmail(email: string): Promise<Member | undefined> {
    // Normalize email for case-insensitive matching
    const normalizedEmail = email.toLowerCase().trim();
    console.log(`[STORAGE] getMemberByEmail called with: "${email}" -> normalized: "${normalizedEmail}"`);
    
    // Try exact match first (normalized)
    let result = await db.select().from(members).where(eq(members.email, normalizedEmail));
    if (result[0]) {
      console.log(`[STORAGE] Found member by exact match: ID=${result[0].id}, email="${result[0].email}", balance=${result[0].totalSolar}`);
      return result[0];
    }
    
    // Try case-insensitive match using SQL LOWER()
    result = await db.select().from(members).where(
      sql`LOWER(TRIM(${members.email})) = ${normalizedEmail}`
    );
    if (result[0]) {
      console.log(`[STORAGE] Found member by case-insensitive match: ID=${result[0].id}, email="${result[0].email}", balance=${result[0].totalSolar}`);
    } else {
      console.log(`[STORAGE] No member found for email: "${normalizedEmail}"`);
    }
    return result[0];
  }
  
  async createMember(data: InsertMember): Promise<Member> {
    const result = await db.insert(members).values(data).returning();
    return result[0];
  }
  
  async updateMember(id: number, data: Partial<InsertMember>): Promise<Member | undefined> {
    const result = await db.update(members)
      .set(data)
      .where(eq(members.id, id))
      .returning();
    return result[0];
  }
  
  async deleteMember(id: number): Promise<boolean> {
    const result = await db.delete(members).where(eq(members.id, id)).returning({ id: members.id });
    return result.length > 0;
  }
  
  // Distribution operations
  async createDistributionLog(data: InsertDistributionLog): Promise<DistributionLog> {
    const result = await db.insert(distributionLogs).values(data).returning();
    return result[0];
  }
  
  async getDistributionLogs(memberId?: number): Promise<DistributionLog[]> {
    if (memberId) {
      return await db.select()
        .from(distributionLogs)
        .where(eq(distributionLogs.memberId, memberId))
        .orderBy(desc(distributionLogs.timestamp));
    }
    return await db.select()
      .from(distributionLogs)
      .orderBy(desc(distributionLogs.timestamp));
  }
  
  async getLastDistribution(memberId: number): Promise<DistributionLog | undefined> {
    const result = await db.select()
      .from(distributionLogs)
      .where(eq(distributionLogs.memberId, memberId))
      .orderBy(desc(distributionLogs.timestamp))
      .limit(1);
    return result[0];
  }
  
  // Backup operations
  async createBackupLog(data: InsertBackupLog): Promise<BackupLog> {
    const result = await db.insert(backupLogs).values(data).returning();
    return result[0];
  }
  
  async getBackupLogs(): Promise<BackupLog[]> {
    return await db.select()
      .from(backupLogs)
      .orderBy(desc(backupLogs.timestamp));
  }
  
  // Import/Export
  async importMembersFromJson(filePath: string): Promise<{ success: boolean, imported: number, errors: any[] }> {
    try {
      const jsonData = fs.readFileSync(filePath, 'utf8');
      const memberList = JSON.parse(jsonData);
      const result = await this.migrateFileBasedMembersToDatabase(memberList);
      return {
        success: result.success,
        imported: result.migrated,
        errors: result.errors
      };
    } catch (error) {
      return { success: false, imported: 0, errors: [error] };
    }
  }
  
  async exportMembersToJson(filePath: string): Promise<{ success: boolean, exported: number }> {
    try {
      const members = await this.getMembers();
      fs.writeFileSync(filePath, JSON.stringify(members, null, 2));
      return { success: true, exported: members.length };
    } catch (error) {
      return { success: false, exported: 0 };
    }
  }
  
  // User operations for timer-gated progression
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(data: InsertUser): Promise<User> {
    const result = await db.insert(users).values(data).returning();
    return result[0];
  }

  async updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async updateUserCredentials(id: string, email: string, hashedPassword: string): Promise<User | undefined> {
    const result = await db.update(users)
      .set({ email, password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // User profile operations
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return result[0];
  }

  async createUserProfile(data: InsertUserProfile): Promise<UserProfile> {
    const result = await db.insert(userProfiles).values(data).returning();
    return result[0];
  }

  async updateUserProfile(userId: string, data: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const result = await db.update(userProfiles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return result[0];
  }

  async updateSolarBalance(userId: string, amount: number): Promise<UserProfile | undefined> {
    const result = await db.update(userProfiles)
      .set({ 
        solarBalance: sql`${userProfiles.solarBalance} + ${amount}`,
        updatedAt: new Date()
      })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return result[0];
  }

  // Progression operations
  async getProgression(userId: string | null, sessionId: string | null, contentType: string, contentId: string): Promise<Progression | undefined> {
    const whereClause = and(
      eq(progressions.contentType, contentType),
      eq(progressions.contentId, contentId),
      userId ? eq(progressions.userId, userId) : eq(progressions.sessionId, sessionId || '')
    );
    
    const result = await db.select().from(progressions).where(whereClause);
    return result[0];
  }

  async getUserProgressions(userId: string | null, sessionId: string | null): Promise<Progression[]> {
    const whereClause = userId 
      ? eq(progressions.userId, userId)
      : eq(progressions.sessionId, sessionId || '');
    
    return await db.select()
      .from(progressions)
      .where(whereClause)
      .orderBy(desc(progressions.createdAt));
  }

  async createProgression(data: InsertProgression): Promise<Progression> {
    const result = await db.insert(progressions).values(data).returning();
    return result[0];
  }

  async updateProgression(id: string, data: Partial<InsertProgression>): Promise<Progression | undefined> {
    const result = await db.update(progressions)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(progressions.id, id))
      .returning();
    return result[0];
  }

  async startTimer(userId: string | null, sessionId: string | null, contentType: string, contentId: string, duration: number): Promise<Progression> {
    const now = new Date();
    const endTime = new Date(now.getTime() + duration * 1000);
    
    const data: InsertProgression = {
      userId,
      sessionId,
      contentType,
      contentId,
      status: 'timer_active',
      timerStartTime: now,
      timerDuration: duration,
      timerEndTime: endTime,
      unlockMethod: 'timer'
    };

    return await this.createProgression(data);
  }

  async completeTimer(progressionId: string): Promise<Progression | undefined> {
    return await this.updateProgression(progressionId, {
      status: 'timer_complete'
    });
  }

  // Entitlement operations
  async getEntitlement(userId: string | null, sessionId: string | null, contentType: string, contentId: string): Promise<Entitlement | undefined> {
    const whereClause = and(
      eq(entitlements.contentType, contentType),
      eq(entitlements.contentId, contentId),
      userId ? eq(entitlements.userId, userId) : eq(entitlements.sessionId, sessionId || ''),
      or(
        sql`${entitlements.expiresAt} IS NULL`,
        sql`${entitlements.expiresAt} > NOW()`
      )
    );
    
    const result = await db.select().from(entitlements).where(whereClause);
    return result[0];
  }

  async getUserEntitlements(userId: string | null, sessionId: string | null): Promise<Entitlement[]> {
    const whereClause = and(
      userId ? eq(entitlements.userId, userId) : eq(entitlements.sessionId, sessionId || ''),
      or(
        sql`${entitlements.expiresAt} IS NULL`,
        sql`${entitlements.expiresAt} > NOW()`
      )
    );
    
    return await db.select()
      .from(entitlements)
      .where(whereClause)
      .orderBy(desc(entitlements.createdAt));
  }

  async createEntitlement(data: InsertEntitlement): Promise<Entitlement> {
    const result = await db.insert(entitlements).values(data).returning();
    return result[0];
  }

  async revokeEntitlement(id: string): Promise<boolean> {
    const result = await db.delete(entitlements).where(eq(entitlements.id, id)).returning({ id: entitlements.id });
    return result.length > 0;
  }

  // Transaction operations
  async createTransaction(data: InsertTransaction): Promise<Transaction> {
    const result = await db.insert(transactions).values(data).returning();
    return result[0];
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return await db.select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async updateTransactionStatus(id: string, status: string, completedAt?: Date): Promise<Transaction | undefined> {
    const updateData: Partial<InsertTransaction> = { status };
    if (completedAt) {
      updateData.completedAt = completedAt;
    }
    
    const result = await db.update(transactions)
      .set(updateData)
      .where(eq(transactions.id, id))
      .returning();
    return result[0];
  }

  // Content library operations
  async getContentLibrary(): Promise<ContentLibrary[]> {
    return await db.select()
      .from(contentLibrary)
      .where(eq(contentLibrary.isActive, true))
      .orderBy(contentLibrary.sortOrder, contentLibrary.createdAt);
  }

  async getContentItem(contentType: string, contentId: string): Promise<ContentLibrary | undefined> {
    const result = await db.select()
      .from(contentLibrary)
      .where(and(
        eq(contentLibrary.contentType, contentType),
        eq(contentLibrary.contentId, contentId),
        eq(contentLibrary.isActive, true)
      ));
    return result[0];
  }

  async createContentItem(data: InsertContentLibrary): Promise<ContentLibrary> {
    const result = await db.insert(contentLibrary).values(data).returning();
    return result[0];
  }

  async updateContentItem(id: string, data: Partial<InsertContentLibrary>): Promise<ContentLibrary | undefined> {
    const result = await db.update(contentLibrary)
      .set(data)
      .where(eq(contentLibrary.id, id))
      .returning();
    return result[0];
  }

  // Composite operations for progression flow
  async canAccessContent(userId: string | null, sessionId: string | null, contentType: string, contentId: string): Promise<{
    canAccess: boolean;
    accessType: 'locked' | 'timer_active' | 'timer_complete' | 'preview' | 'full';
    timeRemaining?: number;
    solarCost?: number;
    progression?: Progression;
    entitlement?: Entitlement;
    userBalance?: number;
  }> {
    // Get user balance if userId is provided
    let userBalance: number | undefined;
    if (userId) {
      const userProfile = await this.getUserProfile(userId);
      userBalance = userProfile?.solarBalance ?? undefined;
    }

    // Check for existing entitlement
    const entitlement = await this.getEntitlement(userId, sessionId, contentType, contentId);
    if (entitlement && entitlement.accessType === 'full') {
      return {
        canAccess: true,
        accessType: 'full',
        entitlement,
        userBalance
      };
    }

    // Check progression status
    const progression = await this.getProgression(userId, sessionId, contentType, contentId);
    const contentItem = await this.getContentItem(contentType, contentId);

    if (!contentItem) {
      return {
        canAccess: false,
        accessType: 'locked',
        userBalance
      };
    }

    // If no progression exists, content is locked
    if (!progression) {
      return {
        canAccess: true,
        accessType: 'preview',
        solarCost: contentItem.solarCost || 0,
        userBalance
      };
    }

    // Check timer status
    if (progression.status === 'timer_active') {
      const now = new Date();
      const endTime = new Date(progression.timerEndTime!);
      const timeRemaining = Math.max(0, Math.floor((endTime.getTime() - now.getTime()) / 1000));
      
      if (timeRemaining > 0) {
        return {
          canAccess: true,
          accessType: 'timer_active',
          timeRemaining,
          progression,
          userBalance
        };
      } else {
        // Timer expired, update status
        await this.completeTimer(progression.id);
        return {
          canAccess: true,
          accessType: 'timer_complete',
          solarCost: contentItem.solarCost || 0,
          progression,
          userBalance
        };
      }
    }

    if (progression.status === 'timer_complete') {
      return {
        canAccess: true,
        accessType: 'timer_complete',
        solarCost: contentItem.solarCost || 0,
        progression,
        userBalance
      };
    }

    if (progression.status === 'unlocked') {
      return {
        canAccess: true,
        accessType: 'full',
        progression,
        userBalance
      };
    }

    // Default to preview
    return {
      canAccess: true,
      accessType: 'preview',
      solarCost: contentItem.solarCost || 0,
      userBalance
    };
  }

  async unlockContentWithPayment(userId: string, contentType: string, contentId: string, solarCost: number): Promise<{
    success: boolean;
    entitlement?: Entitlement;
    transaction?: Transaction;
    error?: string;
  }> {
    return await db.transaction(async (tx) => {
      try {
        // Check user's solar balance
        const userProfile = await this.getUserProfile(userId);
        if (!userProfile || (userProfile.solarBalance ?? 0) < solarCost) {
          return {
            success: false,
            error: 'Insufficient Solar balance'
          };
        }

        // Create spending transaction
        const transaction = await this.createTransaction({
          userId,
          type: 'solar_spend',
          amount: solarCost,
          currency: 'SOLAR',
          status: 'completed',
          description: `Unlock ${contentType}: ${contentId}`,
          completedAt: new Date()
        });

        // Update user's solar balance
        await this.updateSolarBalance(userId, -solarCost);
        // Update total spent using raw SQL
        await db.update(userProfiles)
          .set({ 
            totalSpent: sql`${userProfiles.totalSpent} + ${solarCost}`,
            updatedAt: new Date()
          })
          .where(eq(userProfiles.userId, userId));

        // Create entitlement
        const entitlement = await this.createEntitlement({
          userId,
          contentType,
          contentId,
          accessType: 'full',
          purchaseMethod: 'solar',
          solarCost
        });

        // Update progression status if exists
        const progression = await this.getProgression(userId, null, contentType, contentId);
        if (progression) {
          await this.updateProgression(progression.id, {
            status: 'unlocked',
            unlockMethod: 'payment'
          });
        }

        return {
          success: true,
          entitlement,
          transaction
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Payment failed'
        };
      }
    });
  }

  // Unlock content with Solar tokens
  async unlockWithSolar(userId: string, contentType: string, contentId: string): Promise<{
    success: boolean;
    entitlement?: Entitlement;
    transaction?: Transaction;
    newBalance?: number;
    error?: string;
    message?: string;
  }> {
    return await db.transaction(async (tx) => {
      try {
        // Get content item to check cost
        const contentItem = await this.getContentItem(contentType, contentId);
        if (!contentItem) {
          return {
            success: false,
            error: 'Content not found',
            message: 'The requested content does not exist'
          };
        }

        const solarCost = contentItem.solarCost || 0;
        if (solarCost <= 0) {
          return {
            success: false,
            error: 'Content is free',
            message: 'This content does not require Solar tokens'
          };
        }

        // Check user's solar balance
        const userProfile = await this.getUserProfile(userId);
        if (!userProfile || (userProfile.solarBalance ?? 0) < solarCost) {
          return {
            success: false,
            error: 'Insufficient Solar balance',
            message: `You need ${solarCost} Solar tokens but only have ${userProfile?.solarBalance || 0}`
          };
        }

        // Create spending transaction
        const transaction = await this.createTransaction({
          userId,
          type: 'solar_spend',
          amount: solarCost,
          currency: 'SOLAR',
          status: 'completed',
          description: `Unlock ${contentType}: ${contentId}`,
          completedAt: new Date()
        });

        // Update user's solar balance
        const updatedProfile = await this.updateSolarBalance(userId, -solarCost);
        
        // Update total spent using raw SQL
        await db.update(userProfiles)
          .set({ 
            totalSpent: sql`${userProfiles.totalSpent} + ${solarCost}`,
            updatedAt: new Date()
          })
          .where(eq(userProfiles.userId, userId));

        // Create entitlement
        const entitlement = await this.createEntitlement({
          userId,
          contentType,
          contentId,
          accessType: 'full',
          purchaseMethod: 'solar',
          solarCost
        });

        // Update progression status if exists
        const progression = await this.getProgression(userId, null, contentType, contentId);
        if (progression) {
          await this.updateProgression(progression.id, {
            status: 'unlocked',
            unlockMethod: 'payment'
          });
        }

        return {
          success: true,
          entitlement,
          transaction,
          newBalance: updatedProfile?.solarBalance || 0,
          message: `Successfully unlocked ${contentType} for ${solarCost} Solar tokens`
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Payment failed',
          message: 'An error occurred while processing your Solar payment'
        };
      }
    });
  }

  // Transfer session progressions to user account
  async transferSessionProgressions(sessionId: string, userId: string): Promise<void> {
    try {
      // Find all progressions for this session ID
      const sessionProgressions = await db.select()
        .from(progressions)
        .where(and(
          eq(progressions.sessionId, sessionId),
          sql`${progressions.userId} IS NULL`
        ));

      // Transfer each progression to the user
      for (const progression of sessionProgressions) {
        await db.update(progressions)
          .set({
            userId: userId,
            sessionId: null, // Clear session ID since we now have a user ID
            updatedAt: new Date()
          })
          .where(eq(progressions.id, progression.id));
      }

      console.log(`Transferred ${sessionProgressions.length} progressions from session ${sessionId} to user ${userId}`);
    } catch (error) {
      console.error('Error transferring session progressions:', error);
      throw error;
    }
  }

  // Product operations
  async getAllProducts(): Promise<Product[]> {
    return await db.select()
      .from(products)
      .where(eq(products.isActive, true))
      .orderBy(products.createdAt);
  }

  async getProduct(id: string): Promise<Product | undefined> {
    const result = await db.select().from(products).where(eq(products.id, id));
    return result[0];
  }

  async createProduct(data: InsertProduct): Promise<Product> {
    const result = await db.insert(products).values(data).returning();
    return result[0];
  }

  async updateProduct(id: string, data: Partial<InsertProduct>): Promise<Product | undefined> {
    const result = await db.update(products)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(products.id, id))
      .returning();
    return result[0];
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id)).returning({ id: products.id });
    return result.length > 0;
  }

  // Newsletter subscription operations
  async createNewsletterSubscription(data: InsertNewsletterSubscription): Promise<NewsletterSubscription> {
    const result = await db.insert(newsletterSubscriptions).values(data).returning();
    return result[0];
  }

  async getNewsletterSubscriptions(): Promise<NewsletterSubscription[]> {
    return await db.select()
      .from(newsletterSubscriptions)
      .where(eq(newsletterSubscriptions.status, 'active'))
      .orderBy(desc(newsletterSubscriptions.subscribedAt));
  }

  async getNewsletterSubscriptionByEmail(email: string): Promise<NewsletterSubscription | undefined> {
    const result = await db.select()
      .from(newsletterSubscriptions)
      .where(eq(newsletterSubscriptions.email, email));
    return result[0];
  }

  async unsubscribeNewsletter(email: string): Promise<boolean> {
    const result = await db.update(newsletterSubscriptions)
      .set({ 
        status: 'unsubscribed',
        unsubscribedAt: new Date()
      })
      .where(eq(newsletterSubscriptions.email, email))
      .returning({ id: newsletterSubscriptions.id });
    return result.length > 0;
  }

  // Contact message operations
  async createContactMessage(data: InsertContactMessage): Promise<ContactMessage> {
    const result = await db.insert(contactMessages).values(data).returning();
    return result[0];
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return await db.select()
      .from(contactMessages)
      .orderBy(desc(contactMessages.createdAt));
  }

  async getContactMessage(id: string): Promise<ContactMessage | undefined> {
    const result = await db.select().from(contactMessages).where(eq(contactMessages.id, id));
    return result[0];
  }

  async updateContactMessageStatus(id: string, status: string): Promise<ContactMessage | undefined> {
    const updateData: Partial<InsertContactMessage> = { status };
    if (status === 'replied') {
      updateData.repliedAt = new Date();
    }
    
    const result = await db.update(contactMessages)
      .set(updateData)
      .where(eq(contactMessages.id, id))
      .returning();
    return result[0];
  }

  // Solar accounts (legacy member system compatibility)
  async getAllSolarAccounts(limit?: number, includeAnonymous?: boolean): Promise<Member[]> {
    const baseQuery = db.select().from(members);
    
    if (!includeAnonymous && limit) {
      return await baseQuery
        .where(eq(members.isAnonymous, false))
        .orderBy(desc(members.signupTimestamp))
        .limit(limit);
    } else if (!includeAnonymous) {
      return await baseQuery
        .where(eq(members.isAnonymous, false))
        .orderBy(desc(members.signupTimestamp));
    } else if (limit) {
      return await baseQuery
        .orderBy(desc(members.signupTimestamp))
        .limit(limit);
    } else {
      return await baseQuery
        .orderBy(desc(members.signupTimestamp));
    }
  }

  // Get member Solar balance from members table (single source of truth)
  async getMemberSolarBalance(memberId: number): Promise<number> {
    const result = await db.select({ totalSolar: members.totalSolar })
      .from(members)
      .where(eq(members.id, memberId))
      .limit(1);
    
    if (result.length === 0) {
      return 0;
    }
    return parseFloat(result[0].totalSolar || '0');
  }

  // Update member Solar balance (single source of truth)
  async updateMemberSolarBalance(memberId: number, newBalance: number): Promise<boolean> {
    const result = await db.update(members)
      .set({ totalSolar: String(newBalance) })
      .where(eq(members.id, memberId))
      .returning();
    
    return result.length > 0;
  }

  async createSolarAccount(data: { userId: string; isAnonymous: boolean; displayName: string }): Promise<Member> {
    // Create a member record for the solar account
    const memberData = {
      username: `user_${data.userId}`,
      name: data.displayName,
      email: '', // Will be updated from user data if available
      isAnonymous: data.isAnonymous,
      totalSolar: '0',
      totalDollars: '0'
    };
    
    const result = await db.insert(members).values(memberData).returning();
    return result[0];
  }


  // Migration assistance
  async migrateFileBasedMembersToDatabase(membersList: any[]): Promise<{ success: boolean, migrated: number, errors: any[] }> {
    const errors: any[] = [];
    let migratedCount = 0;
    
    try {
      // Begin transaction
      await db.transaction(async (tx) => {
        for (const memberData of membersList) {
          // Skip placeholders
          if (memberData.isPlaceholder) {
            continue;
          }
          
          try {
            // Prepare member data for database
            const insertData: InsertMember = {
              username: memberData.username,
              name: memberData.name,
              email: memberData.email || `${memberData.username}@thecurrentsee.org`,
              joinedDate: memberData.joinedDate,
              totalSolar: memberData.totalSolar.toString(),
              totalDollars: memberData.totalDollars.toString(),
              isAnonymous: memberData.isAnonymous || false,
              isReserve: memberData.isReserve || false,
              lastDistributionDate: memberData.lastDistributionDate,
              notes: memberData.notes || null
            };
            
            // Check if member already exists (by username)
            const existingMember = await tx.select()
              .from(members)
              .where(eq(members.username, memberData.username))
              .limit(1);
            
            if (existingMember.length === 0) {
              // Create new member
              await tx.insert(members).values(insertData);
              migratedCount++;
            } else {
              // Update existing member
              await tx.update(members)
                .set(insertData)
                .where(eq(members.username, memberData.username));
              migratedCount++;
            }
          } catch (memberError: unknown) {
            errors.push({
              member: memberData.username,
              error: memberError instanceof Error ? memberError.message : String(memberError)
            });
          }
        }
      });
      
      return {
        success: errors.length === 0,
        migrated: migratedCount,
        errors
      };
    } catch (error: unknown) {
      return {
        success: false,
        migrated: migratedCount,
        errors: [...errors, error instanceof Error ? error.message : String(error)]
      };
    }
  }

  // ============================================================
  // MARKETPLACE OPERATIONS IMPLEMENTATION
  // ============================================================

  // Artifact operations
  async getArtifact(id: string): Promise<Artifact | undefined> {
    const result = await db.select().from(artifacts).where(eq(artifacts.id, id));
    return result[0];
  }

  async getArtifactBySlug(slug: string): Promise<Artifact | undefined> {
    const result = await db.select().from(artifacts).where(eq(artifacts.slug, slug));
    return result[0];
  }

  async getAvailableArtifacts(): Promise<Artifact[]> {
    return await db.select().from(artifacts).where(eq(artifacts.active, true)).orderBy(desc(artifacts.createdAt));
  }

  // Artifact copy operations
  async createArtifactCopy(data: InsertArtifactCopy): Promise<ArtifactCopy> {
    const result = await db.insert(artifactCopies).values(data).returning();
    return result[0];
  }

  async getUserArtifactCopies(userId: number): Promise<(ArtifactCopy & { artifact: Artifact })[]> {
    const copies = await db.select()
      .from(artifactCopies)
      .where(and(eq(artifactCopies.ownerId, userId), eq(artifactCopies.isActive, true)))
      .orderBy(desc(artifactCopies.acquiredAt));
    
    // Join with artifacts
    const result = [];
    for (const copy of copies) {
      const artifact = await this.getArtifact(copy.artifactId);
      if (artifact) {
        result.push({ ...copy, artifact });
      }
    }
    return result;
  }

  async getArtifactCopy(userId: number, artifactId: string): Promise<ArtifactCopy | undefined> {
    const result = await db.select()
      .from(artifactCopies)
      .where(and(
        eq(artifactCopies.ownerId, userId),
        eq(artifactCopies.artifactId, artifactId),
        eq(artifactCopies.isActive, true)
      ));
    return result[0];
  }

  // Download token operations
  async createDownloadToken(data: InsertDownloadToken): Promise<DownloadToken> {
    const result = await db.insert(downloadTokens).values(data).returning();
    return result[0];
  }

  async getDownloadToken(token: string): Promise<DownloadToken | undefined> {
    const result = await db.select()
      .from(downloadTokens)
      .where(and(
        eq(downloadTokens.token, token),
        eq(downloadTokens.isRevoked, false)
      ));
    return result[0];
  }

  async incrementDownloadCount(tokenId: string): Promise<void> {
    await db.update(downloadTokens)
      .set({ 
        downloadCount: sql`${downloadTokens.downloadCount} + 1`,
        lastAccessedAt: new Date()
      })
      .where(eq(downloadTokens.id, tokenId));
  }

  // Marketplace ledger operations
  async createLedgerEntry(data: InsertMarketplaceLedgerEntry): Promise<MarketplaceLedgerEntry> {
    const result = await db.insert(marketplaceLedger).values(data).returning();
    return result[0];
  }

  async getLedgerEntriesByTransaction(transactionId: string): Promise<MarketplaceLedgerEntry[]> {
    return await db.select()
      .from(marketplaceLedger)
      .where(eq(marketplaceLedger.transactionId, transactionId))
      .orderBy(marketplaceLedger.createdAt);
  }

  async getLedgerEntriesByAccount(accountId: string, limit: number = 100): Promise<MarketplaceLedgerEntry[]> {
    return await db.select()
      .from(marketplaceLedger)
      .where(eq(marketplaceLedger.accountId, accountId))
      .orderBy(desc(marketplaceLedger.createdAt))
      .limit(limit);
  }

  // Complete purchase flow (atomic transaction)
  async purchaseArtifact(buyerId: number, artifactId: string): Promise<{
    success: boolean;
    copy?: ArtifactCopy;
    downloadToken?: DownloadToken;
    ledgerEntries?: MarketplaceLedgerEntry[];
    error?: string;
  }> {
    try {
      // Pre-transaction validation (outside transaction for early fail)
      const artifact = await this.getArtifact(artifactId);
      if (!artifact) {
        return { success: false, error: 'Artifact not found' };
      }
      if (!artifact.active) {
        return { success: false, error: 'Artifact is not available for purchase' };
      }

      const existingCopy = await this.getArtifactCopy(buyerId, artifactId);
      if (existingCopy) {
        return { success: false, error: 'You already own this artifact' };
      }

      // Get buyer balance from members.total_solar (single source of truth)
      const buyerBalance = await this.getMemberSolarBalance(buyerId);
      if (buyerBalance === 0) {
        // Check if member exists
        const memberExists = await db.select({ id: members.id })
          .from(members)
          .where(eq(members.id, buyerId))
          .limit(1);
        if (memberExists.length === 0) {
          return { success: false, error: 'Member account not found' };
        }
      }

      const price = parseFloat(artifact.solarAmountS || '0');
      const foundationFee = Math.round(price * FOUNDATION_FEE_RATE * 10000) / 10000;
      const sellerNet = price - foundationFee;

      if (buyerBalance < price) {
        return { success: false, error: `Insufficient Solar balance. Need ${price} Solar, have ${buyerBalance.toFixed(5)} Solar` };
      }

      const creatorId = artifact.creatorId;
      const transactionId = `purchase_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Execute purchase in atomic transaction
      const result = await db.transaction(async (tx) => {
        const ledgerEntries: MarketplaceLedgerEntry[] = [];

        // 1. Create debit ledger entry (buyer pays full price)
        const [debitEntry] = await tx.insert(marketplaceLedger).values({
          transactionId,
          entryType: 'debit',
          accountId: String(buyerId),
          accountType: 'user',
          amount: String(price),
          balanceAfter: String(buyerBalance - price),
          referenceType: 'purchase',
          referenceId: artifactId,
          description: `Purchase: ${artifact.title}`
        }).returning();
        ledgerEntries.push(debitEntry);

        // 2. Create credit ledger entry (creator receives sellerNet after foundation fee)
        const [creditEntry] = await tx.insert(marketplaceLedger).values({
          transactionId,
          entryType: 'credit',
          accountId: creatorId,
          accountType: 'creator',
          amount: String(sellerNet),
          referenceType: 'purchase',
          referenceId: artifactId,
          description: `Sale: ${artifact.title}`
        }).returning();
        ledgerEntries.push(creditEntry);

        // 3. Update buyer's Solar balance (deduct)
        await tx.update(members)
          .set({ totalSolar: String(buyerBalance - price) })
          .where(eq(members.id, buyerId));

        // 4. Update creator's Solar balance if they have a member profile
        const creatorMember = await tx.select().from(members)
          .where(or(
            eq(members.id, parseInt(creatorId) || 0),
            eq(members.username, creatorId)
          ))
          .limit(1);
        
        if (creatorMember.length > 0) {
          const creatorBalance = parseFloat(creatorMember[0].totalSolar || '0');
          await tx.update(members)
            .set({ totalSolar: String(creatorBalance + sellerNet) })
            .where(eq(members.id, creatorMember[0].id));
        }

        // 4b. Foundation fee collection
        const foundationMember = await tx.select().from(members).where(eq(members.username, FOUNDATION_USERNAME)).limit(1);
        if (foundationMember.length > 0) {
          const foundationBalance = parseFloat(foundationMember[0].totalSolar || '0');
          const foundationBalAfter = foundationBalance + foundationFee;
          const [foundationEntry] = await tx.insert(marketplaceLedger).values({
            transactionId,
            entryType: 'credit',
            accountId: String(foundationMember[0].id),
            accountType: 'foundation',
            amount: String(foundationFee),
            balanceAfter: String(foundationBalAfter),
            referenceType: 'foundation_fee',
            referenceId: artifactId,
            description: `Foundation fee (5%): ${artifact.title}`
          }).returning();
          ledgerEntries.push(foundationEntry);
          await tx.update(members)
            .set({ totalSolar: String(foundationBalAfter) })
            .where(eq(members.id, foundationMember[0].id));
        } else {
          console.warn('⚠️ Foundation member (tcs_foundation) not found - foundation fee not collected for transaction:', transactionId);
        }

        // 5. Create artifact copy for buyer
        const [copy] = await tx.insert(artifactCopies).values({
          artifactId,
          ownerId: buyerId,
          purchaseTransactionId: transactionId,
          acquiredMethod: 'purchase',
          solarPaid: String(price)
        }).returning();

        // 6. Create download token
        const tokenValue = `dl_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`;
        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + 30); // 30 day expiry

        const [downloadToken] = await tx.insert(downloadTokens).values({
          token: tokenValue,
          artifactId,
          userId: buyerId,
          expiresAt,
          accessType: 'trade_file',
          maxDownloads: 10
        }).returning();

        return { copy, downloadToken, ledgerEntries };
      });

      return {
        success: true,
        copy: result.copy,
        downloadToken: result.downloadToken,
        ledgerEntries: result.ledgerEntries
      };

    } catch (error) {
      console.error('Purchase error:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error during purchase' 
      };
    }
  }

  // ============================================================
  // WALLET OPERATIONS - For Replit Auth wallet claiming
  // ============================================================
  
  async getWalletByEmail(email: string): Promise<Wallet | undefined> {
    const result = await db.select().from(wallets).where(eq(wallets.email, email));
    return result[0];
  }
  
  async getWalletByUserId(userId: string): Promise<Wallet | undefined> {
    const result = await db.select().from(wallets).where(eq(wallets.userId, userId));
    return result[0];
  }
  
  async linkWalletToUser(walletId: string, userId: string): Promise<Wallet | undefined> {
    const result = await db.update(wallets)
      .set({ userId })
      .where(eq(wallets.id, walletId))
      .returning();
    return result[0];
  }
  
  async createWallet(data: { userId: string; email?: string; balanceSolarS?: string; balanceRays?: number; promptCredits?: number }): Promise<Wallet> {
    const result = await db.insert(wallets).values({
      userId: data.userId,
      email: data.email || null,
      balanceSolarS: data.balanceSolarS || "0",
      balanceRays: data.balanceRays || 0,
      promptCredits: data.promptCredits || 0,
    }).returning();
    return result[0];
  }
  
  // Upsert user for Replit Auth
  async upsertUser(data: { id: string; email?: string | null; firstName?: string | null; lastName?: string | null; profileImageUrl?: string | null }): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        id: data.id,
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        profileImageUrl: data.profileImageUrl,
      })
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email: data.email,
          firstName: data.firstName,
          lastName: data.lastName,
          profileImageUrl: data.profileImageUrl,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // ============================================================
  // MARKETPLACE SEARCH & PROCUREMENT OPERATIONS IMPLEMENTATION
  // ============================================================

  // Market Items methods
  async searchMarketItems(query: string, limit = 20): Promise<MarketItem[]> {
    const normalizedQuery = `%${query.toLowerCase()}%`;
    return db.select().from(marketItems)
      .where(
        and(
          eq(marketItems.status, 'ACTIVE'),
          or(
            sql`LOWER(${marketItems.searchText}) LIKE ${normalizedQuery}`,
            sql`LOWER(${marketItems.title}) LIKE ${normalizedQuery}`
          )
        )
      )
      .limit(limit);
  }

  async getMarketItemById(id: string): Promise<MarketItem | undefined> {
    const result = await db.select().from(marketItems).where(eq(marketItems.id, id));
    return result[0];
  }

  async getMarketItemsByStatus(status: string): Promise<MarketItem[]> {
    return db.select().from(marketItems)
      .where(eq(marketItems.status, status))
      .orderBy(desc(marketItems.createdAt));
  }

  async createMarketItem(item: InsertMarketItem): Promise<MarketItem> {
    const result = await db.insert(marketItems).values(item).returning();
    return result[0];
  }

  async updateMarketItem(id: string, updates: Partial<InsertMarketItem>): Promise<MarketItem | undefined> {
    const result = await db.update(marketItems)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(marketItems.id, id))
      .returning();
    return result[0];
  }

  async publishMarketItem(id: string): Promise<MarketItem | undefined> {
    const result = await db.update(marketItems)
      .set({ status: 'ACTIVE', updatedAt: new Date() })
      .where(eq(marketItems.id, id))
      .returning();
    return result[0];
  }

  // Market Requests methods
  async createMarketRequest(request: InsertMarketRequest): Promise<MarketRequest> {
    const result = await db.insert(marketRequests).values(request).returning();
    return result[0];
  }

  async getMarketRequestById(id: string): Promise<MarketRequest | undefined> {
    const result = await db.select().from(marketRequests).where(eq(marketRequests.id, id));
    return result[0];
  }

  async getMarketRequestsByStatus(status: string): Promise<MarketRequest[]> {
    return db.select().from(marketRequests)
      .where(eq(marketRequests.status, status))
      .orderBy(desc(marketRequests.createdAt));
  }

  async updateMarketRequestStatus(id: string, status: string): Promise<MarketRequest | undefined> {
    const result = await db.update(marketRequests)
      .set({ status, updatedAt: new Date() })
      .where(eq(marketRequests.id, id))
      .returning();
    return result[0];
  }

  // Procurement Recommendations methods
  async createProcurementRecommendation(rec: InsertProcurementRecommendation): Promise<ProcurementRecommendation> {
    const result = await db.insert(procurementRecommendations).values(rec).returning();
    return result[0];
  }

  async getRecommendationsByRequestId(requestId: string): Promise<ProcurementRecommendation[]> {
    return db.select().from(procurementRecommendations)
      .where(eq(procurementRecommendations.requestId, requestId))
      .orderBy(desc(procurementRecommendations.createdAt));
  }

  // Procurement Reviews methods
  async createProcurementReview(review: InsertProcurementReview): Promise<ProcurementReview> {
    const result = await db.insert(procurementReviews).values(review).returning();
    return result[0];
  }

  async getReviewByRequestId(requestId: string): Promise<ProcurementReview | undefined> {
    const result = await db.select().from(procurementReviews)
      .where(eq(procurementReviews.requestId, requestId));
    return result[0];
  }
}

// Export an instance of the storage
export const storage = new DatabaseStorage();