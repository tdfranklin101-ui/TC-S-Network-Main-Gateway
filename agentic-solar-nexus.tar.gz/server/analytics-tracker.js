/**
 * Geographic Analytics Tracker
 * Privacy-focused aggregate visitor tracking by country and US state
 * Stores only monthly totals - no individual user tracking
 * Uses cloud-based ip-api.com for always up-to-date geo-location
 */

const { Pool } = require('@neondatabase/serverless');

class AnalyticsTracker {
  constructor(databaseUrl) {
    this.pool = new Pool({ connectionString: databaseUrl });
    this.geoCache = new Map(); // Cache geo lookups for 1 hour to reduce API calls
    this.CACHE_TTL = 60 * 60 * 1000; // 1 hour in milliseconds
    // Historical offset to restore pre-deployment visit count
    // Production database separate from workspace - needs offset restoration
    // Updated Nov 4, 2025: Adjusted from 9,716 to 10,272 to account for missed tracking
    // Period: Oct 31-Nov 4 (Thu-Mon) = +556 visits from Replit analytics
    // Baseline: 11,027 (Oct 31) + 600 requests (Nov 1-4) = 11,627 target
    // HISTORICAL_OFFSET accounts for pre-database visitors + Nov 7-Dec 31 2025 tracking gap
    // Gap caused by isProduction() failing to detect Cloud Run deployment (fixed Dec 31, 2025)
    // Dec 2025 Replit Analytics: 676 unique IPs (added to previous offset)
    this.HISTORICAL_OFFSET = 10948;
    
    // Historical country-level offsets (cumulative page views from pre-deployment database)
    // Original baseline (Oct 11, 2025): 9,716 total cumulative page views since April 7, 2025
    // Updated Dec 31, 2025: Added ~600 US visitors from Dec tracking gap
    this.COUNTRY_OFFSETS = {
      'US': 6826,
      'CA': 650,
      'GB': 460,
      'DE': 325,
      'CN': 276,
      'AU': 265,
      'IN': 226,
      'JP': 200,
      'RU': 183,
      'FR': 153,
      'NL': 114,
      'SE': 57,
      'ES': 33,
      'BR': 28,
      'PL': 25,
      'IT': 23,
      'ZA': 12,
      'SG': 2
    };
  }

  /**
   * Get geographic location from IP address using cloud API
   * @param {string} ip - IP address to lookup
   * @returns {Promise<object>} Geographic data (never null - uses fallback for unknown IPs)
   */
  async getLocationFromIP(ip) {
    // Fallback location for private/internal IPs or unknown locations
    const fallbackLocation = {
      countryCode: 'XX',
      countryName: 'Unknown',
      stateCode: '',
      stateName: ''
    };

    // Check for private/local IPs - use fallback but still track
    if (!ip || ip === '127.0.0.1' || ip === '::1' || ip.startsWith('192.168.') || ip.startsWith('10.')) {
      console.log(`📍 Private/local IP detected: ${ip} - using fallback location`);
      return fallbackLocation;
    }

    // Check cache first
    const cached = this.geoCache.get(ip);
    if (cached && (Date.now() - cached.timestamp) < this.CACHE_TTL) {
      console.log(`📍 Using cached geo for: ${ip}`);
      return cached.location;
    }

    try {
      // Use ip-api.com (free, no API key required, 45 requests/minute limit)
      const response = await fetch(`http://ip-api.com/json/${ip}?fields=status,country,countryCode,region,regionName`);
      const data = await response.json();

      if (data.status === 'success') {
        const location = {
          countryCode: data.countryCode,
          countryName: data.country,
          stateCode: data.countryCode === 'US' && data.region ? data.region : '',
          stateName: data.countryCode === 'US' && data.regionName ? data.regionName : ''
        };
        
        // Cache the result
        this.geoCache.set(ip, { location, timestamp: Date.now() });
        console.log(`📍 Cloud geo lookup: ${ip} → ${data.country}`);
        return location;
      }
    } catch (error) {
      console.log(`📍 Cloud geo lookup failed for ${ip}: ${error.message}`);
    }

    // Fallback to local geoip-lite if cloud fails
    try {
      const geoip = require('geoip-lite');
      const geo = geoip.lookup(ip);
      if (geo) {
        return {
          countryCode: geo.country,
          countryName: this.getCountryName(geo.country),
          stateCode: geo.country === 'US' && geo.region ? geo.region : '',
          stateName: geo.country === 'US' && geo.region ? this.getUSStateName(geo.region) : ''
        };
      }
    } catch (e) {
      console.log(`📍 Local geoip fallback also failed`);
    }

    console.log(`📍 GeoIP lookup failed for: ${ip} - using fallback location`);
    return fallbackLocation;
  }

  /**
   * Get country name from ISO code
   * @param {string} code - ISO 3166-1 alpha-2 country code
   * @returns {string} Country name
   */
  getCountryName(code) {
    const countries = {
      'US': 'United States',
      'CA': 'Canada',
      'GB': 'United Kingdom',
      'DE': 'Germany',
      'FR': 'France',
      'IT': 'Italy',
      'ES': 'Spain',
      'AU': 'Australia',
      'NZ': 'New Zealand',
      'JP': 'Japan',
      'CN': 'China',
      'IN': 'India',
      'BR': 'Brazil',
      'MX': 'Mexico',
      'AR': 'Argentina',
      'ZA': 'South Africa',
      'KR': 'South Korea',
      'RU': 'Russia',
      'NL': 'Netherlands',
      'SE': 'Sweden',
      'NO': 'Norway',
      'DK': 'Denmark',
      'FI': 'Finland',
      'CH': 'Switzerland',
      'AT': 'Austria',
      'BE': 'Belgium',
      'PT': 'Portugal',
      'IE': 'Ireland',
      'PL': 'Poland',
      'CZ': 'Czech Republic',
      'GR': 'Greece',
      'TR': 'Turkey',
      'IL': 'Israel',
      'SG': 'Singapore',
      'MY': 'Malaysia',
      'TH': 'Thailand',
      'ID': 'Indonesia',
      'PH': 'Philippines',
      'VN': 'Vietnam',
      'EG': 'Egypt',
      'NG': 'Nigeria',
      'KE': 'Kenya',
      'CL': 'Chile',
      'CO': 'Colombia',
      'PE': 'Peru',
      'VE': 'Venezuela'
    };
    return countries[code] || code;
  }

  /**
   * Get US state name from state code
   * @param {string} code - Two-letter US state code
   * @returns {string} State name
   */
  getUSStateName(code) {
    const states = {
      'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas',
      'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware',
      'FL': 'Florida', 'GA': 'Georgia', 'HI': 'Hawaii', 'ID': 'Idaho',
      'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas',
      'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland',
      'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi',
      'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada',
      'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York',
      'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio', 'OK': 'Oklahoma',
      'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina',
      'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah',
      'VT': 'Vermont', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia',
      'WI': 'Wisconsin', 'WY': 'Wyoming', 'DC': 'District of Columbia'
    };
    return states[code] || code;
  }

  /**
   * Get current date in YYYY-MM-DD format
   * @returns {string} Current date
   */
  getCurrentDate() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  /**
   * Detect if running in production environment
   * Supports Autoscale (K_SERVICE), Reserved VM, and Static deployments
   * @returns {boolean} True if production
   */
  isProduction() {
    // Check for production indicators
    const nodeEnv = process.env.NODE_ENV;
    const replitDeployment = process.env.REPLIT_DEPLOYMENT;
    const replDeploy = process.env.REPL_DEPLOY;
    const kService = process.env.K_SERVICE; // Cloud Run/Autoscale sets this
    const replitDev = process.env.REPLIT_DEV; // Only set in development workspace
    const replSlug = process.env.REPL_SLUG;
    const replOwner = process.env.REPL_OWNER;
    const port = process.env.PORT;
    
    // Production if:
    // 1. NODE_ENV is explicitly 'production', OR
    // 2. REPLIT_DEPLOYMENT is set to '1' (Reserved VM and other deployments), OR
    // 3. REPL_DEPLOY is truthy, OR
    // 4. K_SERVICE is set (Cloud Run/Autoscale indicator), OR
    // 5. REPLIT_DEV is NOT set and we have REPL_SLUG (Reserved VM detection), OR
    // 6. PORT is set (deployment typically sets PORT), OR
    // 7. Default to production if no clear development indicator (REPLIT_DEV not set)
    const isCloudRun = Boolean(kService);
    const isReservedVM = !replitDev && Boolean(replSlug);
    const hasDeploymentPort = Boolean(port);
    const noClearDevIndicator = !replitDev;
    
    const isProd = nodeEnv === 'production' || 
                   replitDeployment === '1' ||
                   Boolean(replDeploy && replDeploy !== 'false' && replDeploy !== '0') ||
                   isCloudRun ||
                   isReservedVM ||
                   (hasDeploymentPort && noClearDevIndicator);
    
    // Log once on first check (only if not already logged)
    if (!this._envLogged) {
      console.log(`📊 Analytics Environment Detection:`);
      console.log(`   NODE_ENV: ${nodeEnv || 'not set'}`);
      console.log(`   REPLIT_DEPLOYMENT: ${replitDeployment || 'not set'}`);
      console.log(`   K_SERVICE (Autoscale): ${kService || 'not set'}`);
      console.log(`   REPLIT_DEV: ${replitDev || 'not set'}`);
      console.log(`   PORT: ${port || 'not set'}`);
      console.log(`   Reserved VM detection: ${isReservedVM ? 'YES' : 'NO'}`);
      console.log(`   → Environment: ${isProd ? 'PRODUCTION ✅' : 'DEVELOPMENT'}`);
      this._envLogged = true;
    }
    
    return isProd;
  }

  /**
   * Track a page visit with geographic data
   * Updates daily aggregate counts for ALL environments (tagged as prod/dev)
   * @param {string} ip - Visitor IP address
   */
  async trackVisit(ip) {
    try {
      // Determine environment (track all, tag them appropriately)
      const environment = this.isProduction() ? 'production' : 'development';
      console.log(`📊 trackVisit() called - IP: ${ip}, Environment: ${environment}`);

      const location = await this.getLocationFromIP(ip);
      // Location is now never null - always has fallback
      
      const date = this.getCurrentDate();

      // Upsert daily aggregate (now tracks both dev and prod, tagged separately)
      await this.pool.query(`
        INSERT INTO geo_analytics (date, environment, country_code, country_name, state_code, state_name, visit_count, updated_at)
        VALUES ($1, $2, $3, $4, $5, $6, 1, CURRENT_TIMESTAMP)
        ON CONFLICT (date, environment, country_code, COALESCE(state_code, ''))
        DO UPDATE SET
          visit_count = geo_analytics.visit_count + 1,
          updated_at = CURRENT_TIMESTAMP
      `, [
        date,
        environment,
        location.countryCode,
        location.countryName,
        location.stateCode,
        location.stateName
      ]);

      console.log(`✅ Analytics [${environment}]: +1 visit from ${location.countryName}${location.stateName ? ', ' + location.stateName : ''} (${date})`);
    } catch (error) {
      console.error('❌ Analytics tracking error:', error.message);
      console.error('❌ Error details:', error);
      // Don't throw - tracking failures shouldn't break the site
    }
  }

  /**
   * Express middleware to track page visits
   * @returns {Function} Express middleware
   */
  middleware() {
    return async (req, res, next) => {
      // Get visitor IP address (handle proxies)
      const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() 
        || req.headers['x-real-ip'] 
        || req.connection.remoteAddress 
        || req.socket.remoteAddress;

      // Track visit asynchronously (don't block the request)
      this.trackVisit(ip).catch(err => {
        console.error('Analytics tracking failed:', err.message);
      });

      next();
    };
  }

  /**
   * Get all daily analytics (production only) grouped by month for display
   * @returns {Promise<Array>} Analytics data grouped by month
   */
  async getMonthlyAnalytics() {
    try {
      const result = await this.pool.query(`
        SELECT 
          SUBSTRING(date, 1, 7) as month,
          country_code,
          country_name,
          state_code,
          state_name,
          SUM(visit_count) as visit_count
        FROM geo_analytics
        WHERE environment = 'production'
        GROUP BY SUBSTRING(date, 1, 7), country_code, country_name, state_code, state_name
        ORDER BY month DESC, visit_count DESC
      `);
      return result.rows;
    } catch (error) {
      console.error('Error fetching analytics:', error);
      return [];
    }
  }

  /**
   * Get analytics summary for a specific month (production only)
   * @param {string} month - Month in YYYY-MM format
   * @returns {Promise<object>} Analytics summary
   */
  async getMonthSummary(month) {
    try {
      const result = await this.pool.query(`
        SELECT 
          country_code,
          country_name,
          state_code,
          state_name,
          SUM(visit_count) as visit_count
        FROM geo_analytics
        WHERE environment = 'production' AND date LIKE $1
        GROUP BY country_code, country_name, state_code, state_name
        ORDER BY visit_count DESC
      `, [month + '%']);

      const totalVisits = result.rows.reduce((sum, row) => sum + parseInt(row.visit_count), 0);
      const topCountries = result.rows
        .filter(row => !row.state_code) // Only country-level data
        .slice(0, 10);

      const usStates = result.rows
        .filter(row => row.country_code === 'US' && row.state_code)
        .sort((a, b) => b.visit_count - a.visit_count);

      return {
        month,
        totalVisits,
        topCountries,
        usStates
      };
    } catch (error) {
      console.error('Error fetching month summary:', error);
      return {
        month,
        totalVisits: 0,
        topCountries: [],
        usStates: []
      };
    }
  }

  /**
   * Get total visits since inception (production only)
   * @returns {Promise<number>} Total visit count
   */
  async getTotalVisits() {
    try {
      const result = await this.pool.query(`
        SELECT SUM(visit_count) as total
        FROM geo_analytics
        WHERE environment = 'production'
      `);
      const currentTotal = parseInt(result.rows[0]?.total || 0);
      // Add historical offset to restore pre-deployment cumulative count
      return currentTotal + this.HISTORICAL_OFFSET;
    } catch (error) {
      console.error('Error fetching total visits:', error);
      return this.HISTORICAL_OFFSET; // Return offset even on error to show historical data
    }
  }

  /**
   * Get visits for today (production only)
   * @returns {Promise<number>} Today's visit count
   */
  async getTodayVisits() {
    try {
      const date = this.getCurrentDate();
      
      const result = await this.pool.query(`
        SELECT COALESCE(SUM(visit_count), 0) as today_visits
        FROM geo_analytics
        WHERE environment = 'production' AND date = $1
      `, [date]);

      return parseInt(result.rows[0]?.today_visits) || 0;
    } catch (error) {
      console.error('Error getting today visits:', error);
      return 0;
    }
  }

  /**
   * Get all-time country totals with historical offsets (production only)
   * @returns {Promise<Array>} Country totals since inception
   */
  async getAllTimeCountryTotals() {
    try {
      const result = await this.pool.query(`
        SELECT 
          country_code,
          country_name,
          SUM(visit_count) as visit_count
        FROM geo_analytics
        WHERE environment = 'production' AND (state_code IS NULL OR state_code = '')
        GROUP BY country_code, country_name
        ORDER BY visit_count DESC
      `);

      // Apply historical offsets to restore pre-deployment cumulative totals
      const countriesWithOffsets = result.rows.map(row => {
        const historicalOffset = this.COUNTRY_OFFSETS[row.country_code] || 0;
        return {
          country_code: row.country_code,
          country_name: row.country_name,
          visit_count: parseInt(row.visit_count) + historicalOffset
        };
      });

      // Add countries that only exist in historical data (not yet in current database)
      const currentCountries = new Set(result.rows.map(r => r.country_code));
      for (const [code, count] of Object.entries(this.COUNTRY_OFFSETS)) {
        if (!currentCountries.has(code)) {
          countriesWithOffsets.push({
            country_code: code,
            country_name: this.getCountryName(code),
            visit_count: count
          });
        }
      }

      // Sort by visit count descending
      return countriesWithOffsets.sort((a, b) => b.visit_count - a.visit_count);
    } catch (error) {
      console.error('Error fetching all-time country totals:', error);
      // Return historical data on error
      return Object.entries(this.COUNTRY_OFFSETS).map(([code, count]) => ({
        country_code: code,
        country_name: this.getCountryName(code),
        visit_count: count
      })).sort((a, b) => b.visit_count - a.visit_count);
    }
  }

  /**
   * Close database connection
   */
  async close() {
    await this.pool.end();
  }
}

module.exports = AnalyticsTracker;
