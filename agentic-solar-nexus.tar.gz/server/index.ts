import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import path from "path";
import { runMigrations } from "./migration";
import fs from "fs";
import { setupHealthChecks } from "./health-check";

// Set environment variables
process.env.SESSION_SECRET = process.env.SESSION_SECRET || 'currentsee-session-secret';

// Handle missing DATABASE_URL in production
if (!process.env.DATABASE_URL && process.env.NODE_ENV === 'production') {
  console.warn('WARNING: DATABASE_URL is not set in production environment. Using in-memory mode.');
  process.env.USE_IN_MEMORY_MODE = 'true';
} else if (!process.env.DATABASE_URL) {
  console.warn('WARNING: DATABASE_URL is not set. Using default development database URL.');
  process.env.DATABASE_URL = 'postgres://postgres:postgres@localhost:5432/postgres';
}

const app = express();

// Initialize health checks BEFORE any other middleware
setupHealthChecks(app);

// Root path handler with special handling for health checks
// This must come AFTER the health check middleware but BEFORE other middleware
app.get('/', (req, res, next) => {
  // Special support for Replit deployment health checks
  // They often don't include standard headers but need special handling
  const isReplitDeploy = req.headers['x-forwarded-for'] !== undefined && 
                          !req.headers.accept?.includes('html');
  
  // If this might be a Replit health check
  if (isReplitDeploy) {
    console.log('Possible Replit deployment health check detected');
    return res.status(200).json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      service: 'thecurrentsee'
    });
  }
  
  // For normal web requests, check if index.html exists in the public folder
  const indexPath = path.join(process.cwd(), 'public', 'index.html');
  if (fs.existsSync(indexPath) && req.path === '/') {
    return res.sendFile(indexPath);
  }
  
  // Otherwise continue to the next handler
  next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve static files from public folder with higher priority
app.use(express.static(path.join(process.cwd(), 'public')));

// Serve files from object storage
app.get('/storage/*', async (req, res) => {
  try {
    const storagePath = req.path.replace('/storage/', '');
    const { Client } = await import('@replit/object-storage');
    const client = new Client();
    
    const result = await client.downloadAsBytes(storagePath);
    if (result.ok) {
      // Determine content type from file extension
      const ext = storagePath.split('.').pop()?.toLowerCase();
      const contentTypes: Record<string, string> = {
        'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'gif': 'image/gif',
        'webp': 'image/webp', 'mp4': 'video/mp4', 'webm': 'video/webm',
        'mp3': 'audio/mpeg', 'wav': 'audio/wav', 'ogg': 'audio/ogg',
        'pdf': 'application/pdf', 'txt': 'text/plain', 'json': 'application/json'
      };
      const contentType = contentTypes[ext || ''] || 'application/octet-stream';
      
      res.set('Content-Type', contentType);
      res.set('Content-Length', String(result.value.length));
      res.send(result.value);
    } else {
      res.status(404).json({ error: 'File not found' });
    }
  } catch (error: any) {
    console.error('Object storage error:', error);
    res.status(500).json({ error: 'Failed to retrieve file' });
  }
});

// Explicit route for solar_counter.js to ensure it's available in production
app.get('/solar_counter.js', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'solar_counter.js'));
});

// Specific routes for our HTML pages
app.get('/founder_note.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'founder_note.html'));
});

app.get('/whitepapers.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'whitepapers.html'));
});

app.get('/signup.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'signup.html'));
});

app.get('/dmtxactly.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'dmtxactly.html'));
});

app.get('/solar-dashboard.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'solar-dashboard.html'));
});

app.get('/sale-offering.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'sale-offering.html'));
});

// White paper HTML files
app.get('/white_paper_1.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'white_paper_1.html'));
});

app.get('/white_paper_2.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'white_paper_2.html'));
});

app.get('/white_paper_3.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'white_paper_3.html'));
});

app.get('/white_paper_4.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'white_paper_4.html'));
});

app.get('/white_paper_5.html', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'white_paper_5.html'));
});

// Admin routes
app.get('/admin', (req, res) => {
  res.redirect('/admin/login');
});

app.get('/admin/login', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'admin', 'login.html'));
});

app.get('/admin/dashboard', (req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'admin', 'dashboard.html'));
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Import the template-to-static module synchronously if possible
import './template-to-static';
console.log('Static page generation complete');

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = process.env.PORT || 5000;
  server.listen({
    port: port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`Server running on port ${port}`);
    log(`Environment: ${process.env.NODE_ENV}`);
  });

  // Run database operations in background (non-blocking)
  // This allows the health checks to pass immediately
  (async () => {
    try {
      // Run schema push to ensure all tables exist
      console.log('Ensuring database schema is up to date...');
      const createTables = (await import('./push-schema')).createTables;
      await createTables();
      console.log('Database schema updated successfully');
    } catch (schemaError) {
      console.error('Error updating database schema:', schemaError);
    }

    // Run data migrations from CSV to database
    try {
      await runMigrations();
    } catch (error) {
      console.error('Error running migrations:', error);
    }
  })();
})();
