import express from "express";
import { db } from "../db";
import { eq, desc, sql, and } from "drizzle-orm";
import { 
  gumballProducts, 
  gumballTransactions, 
  gumballs, 
  gumballJobs, 
  gumballAssets,
  wallets 
} from "@shared/schema";
import { nightMarketJuggler, composePrompt } from "../gumballs/nightMarketJuggler";
import { isAuthenticated } from "../replitAuth";

const router = express.Router();

// Constants
const RAYS_PER_SOLAR = 10000;

// Helper: Get wallet by userId
async function getWalletByUserId(userId: string) {
  return db.select().from(wallets).where(eq(wallets.userId, userId)).then(r => r[0]);
}

// GET /api/gumball/me - Current user session with promptCredits
router.get("/me", isAuthenticated, async (req, res) => {
  try {
    const userId = (req.user as any)?.claims?.sub;
    
    if (!userId) {
      return res.json({ 
        userId: null, 
        promptCredits: 0, 
        message: "Not authenticated" 
      });
    }
    
    const wallet = await getWalletByUserId(userId);
    
    if (!wallet) {
      return res.json({
        userId,
        promptCredits: 0,
        balanceRays: 0,
        message: "No wallet found - please claim your wallet first"
      });
    }
    
    res.json({
      userId,
      promptCredits: wallet.promptCredits || 0,
      balanceRays: wallet.balanceRays || 0
    });
  } catch (error) {
    console.error("Error fetching gumball user:", error);
    res.status(500).json({ error: "Failed to fetch user data" });
  }
});

// GET /api/gumball/products - List active products with Rays/Solar pricing
router.get("/products", async (req, res) => {
  try {
    const products = await db.select()
      .from(gumballProducts)
      .where(eq(gumballProducts.active, true))
      .orderBy(gumballProducts.priceRays);
    
    const productsWithSolar = products.map(p => ({
      ...p,
      priceSolar: (p.priceRays / RAYS_PER_SOLAR).toFixed(4),
      priceUsd: (p.priceRays / RAYS_PER_SOLAR * 0.10).toFixed(2) // Approximate USD value
    }));
    
    res.json(productsWithSolar);
  } catch (error) {
    console.error("Error fetching gumball products:", error);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

// POST /api/gumball/buy - Redirect to external checkout
router.post("/buy", isAuthenticated, async (req, res) => {
  try {
    const { productId, currency } = req.body;
    const authenticatedUserId = (req.user as any)?.claims?.sub;
    
    if (!productId || !currency) {
      return res.status(400).json({ error: "Missing productId or currency" });
    }
    
    const product = await db.select()
      .from(gumballProducts)
      .where(eq(gumballProducts.id, productId))
      .then(r => r[0]);
    
    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }
    
    // Get checkout URL from environment based on product tier
    const tierMap: { [key: number]: string } = {
      5: "5",
      20: "20",
      100: "100"
    };
    const tier = tierMap[product.pulls] || "5";
    const envKey = `CHECKOUT_${currency.toUpperCase()}_${tier}`;
    const checkoutUrl = process.env[envKey] || `https://checkout.example.com/${currency.toLowerCase()}/${tier}`;
    
    // Create transaction record
    const transaction = await db.insert(gumballTransactions).values({
      visitorId: authenticatedUserId,
      productId,
      currency: currency.toUpperCase(),
      status: "pending",
      checkoutUrl,
      priceRays: product.priceRays,
      pullsPurchased: product.pulls
    }).returning();
    
    res.json({
      transactionId: transaction[0].id,
      checkoutUrl,
      product: {
        name: product.name,
        pulls: product.pulls,
        priceRays: product.priceRays
      }
    });
  } catch (error) {
    console.error("Error processing gumball purchase:", error);
    res.status(500).json({ error: "Failed to process purchase" });
  }
});

// POST /api/gumball/confirm - Confirm a purchase (webhook only)
router.post("/confirm", async (req, res) => {
  try {
    const { transactionId, webhookSecret } = req.body;
    
    // Require webhook secret for confirmation (admin/webhook only)
    const validSecret = process.env.GUMBALL_WEBHOOK_SECRET;
    if (!validSecret || webhookSecret !== validSecret) {
      return res.status(403).json({ error: "Invalid webhook secret" });
    }
    
    if (!transactionId) {
      return res.status(400).json({ error: "Missing transactionId" });
    }
    
    const transaction = await db.select()
      .from(gumballTransactions)
      .where(eq(gumballTransactions.id, transactionId))
      .then(r => r[0]);
    
    if (!transaction) {
      return res.status(404).json({ error: "Transaction not found" });
    }
    
    if (transaction.status === "confirmed") {
      return res.json({ message: "Already confirmed", transaction });
    }
    
    // Wallet should already exist for the user
    const wallet = await getWalletByUserId(transaction.visitorId);
    if (!wallet) {
      return res.status(400).json({ error: "No wallet found for user" });
    }
    
    // Update transaction status
    await db.update(gumballTransactions)
      .set({ status: "confirmed", confirmedAt: new Date() })
      .where(eq(gumballTransactions.id, transactionId));
    
    // Add credits to wallet and verify update succeeded
    const updatedWallet = await db.update(wallets)
      .set({ promptCredits: sql`COALESCE(${wallets.promptCredits}, 0) + ${transaction.pullsPurchased}` })
      .where(eq(wallets.userId, transaction.visitorId))
      .returning();
    
    if (updatedWallet.length === 0) {
      console.error(`[GumballConfirm] Failed to credit wallet for visitor ${transaction.visitorId}`);
      return res.status(500).json({ error: "Failed to credit wallet" });
    }
    
    console.log(`[GumballConfirm] Credited ${transaction.pullsPurchased} credits to ${transaction.visitorId}, new balance: ${updatedWallet[0].promptCredits}`);
    
    res.json({ 
      success: true, 
      creditsAdded: transaction.pullsPurchased,
      newBalance: updatedWallet[0].promptCredits
    });
  } catch (error) {
    console.error("Error confirming gumball purchase:", error);
    res.status(500).json({ error: "Failed to confirm purchase" });
  }
});

// POST /api/gumball/vend - Atomically decrement credit and create gumball
router.post("/vend", isAuthenticated, async (req, res) => {
  try {
    const authenticatedUserId = (req.user as any)?.claims?.sub;
    
    const wallet = await getWalletByUserId(authenticatedUserId);
    if (!wallet) {
      return res.status(400).json({ error: "No wallet found - please claim your wallet first" });
    }
    
    if (!wallet.promptCredits || wallet.promptCredits < 1) {
      return res.status(400).json({ error: "Insufficient prompt credits", promptCredits: wallet.promptCredits || 0 });
    }
    
    // Atomically decrement credits
    const updatedWallet = await db.update(wallets)
      .set({ promptCredits: sql`${wallets.promptCredits} - 1` })
      .where(and(
        eq(wallets.userId, authenticatedUserId),
        sql`${wallets.promptCredits} >= 1`
      ))
      .returning();
    
    if (updatedWallet.length === 0) {
      return res.status(400).json({ error: "Failed to decrement credits - race condition" });
    }
    
    // Create gumball using Night Market Juggler generator
    const generator = nightMarketJuggler;
    
    const gumball = await db.insert(gumballs).values({
      visitorId: authenticatedUserId,
      title: generator.title,
      type: generator.type,
      promptMain: generator.promptMain,
      remixJson: generator.remixes,
      mcpRunbook: generator.mcpRunbook
    }).returning();
    
    res.json({
      gumball: gumball[0],
      remainingCredits: updatedWallet[0].promptCredits
    });
  } catch (error) {
    console.error("Error vending gumball:", error);
    res.status(500).json({ error: "Failed to vend gumball" });
  }
});

// POST /api/gumball/run - Create job with composed prompt
router.post("/run", isAuthenticated, async (req, res) => {
  try {
    const { gumballId, remixId } = req.body;
    const authenticatedUserId = (req.user as any)?.claims?.sub;
    
    if (!gumballId) {
      return res.status(400).json({ error: "Missing gumballId" });
    }
    
    const gumball = await db.select()
      .from(gumballs)
      .where(eq(gumballs.id, gumballId))
      .then(r => r[0]);
    
    if (!gumball) {
      return res.status(404).json({ error: "Gumball not found" });
    }
    
    // Compose the prompt with selected remix
    const composedPrompt = composePrompt(nightMarketJuggler, remixId || "");
    
    // Create job
    const job = await db.insert(gumballJobs).values({
      visitorId: authenticatedUserId,
      gumballId,
      status: "QUEUED",
      provider: "SORA_MANUAL",
      composedPrompt,
      selectedRemixId: remixId || null
    }).returning();
    
    res.json({
      job: job[0],
      composedPrompt
    });
  } catch (error) {
    console.error("Error creating gumball job:", error);
    res.status(500).json({ error: "Failed to create job" });
  }
});

// GET /api/gumball/job/:jobId - Get job status and assets
router.get("/job/:jobId", async (req, res) => {
  try {
    const { jobId } = req.params;
    
    const job = await db.select()
      .from(gumballJobs)
      .where(eq(gumballJobs.id, jobId))
      .then(r => r[0]);
    
    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }
    
    const assets = await db.select()
      .from(gumballAssets)
      .where(eq(gumballAssets.jobId, jobId));
    
    res.json({
      job,
      assets
    });
  } catch (error) {
    console.error("Error fetching gumball job:", error);
    res.status(500).json({ error: "Failed to fetch job" });
  }
});

// GET /api/gumball/jobs - Get all jobs for the authenticated user
router.get("/jobs", isAuthenticated, async (req, res) => {
  try {
    const userId = (req.user as any)?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    const jobs = await db.select()
      .from(gumballJobs)
      .where(eq(gumballJobs.visitorId, userId))
      .orderBy(desc(gumballJobs.createdAt));
    
    res.json(jobs);
  } catch (error) {
    console.error("Error fetching gumball jobs:", error);
    res.status(500).json({ error: "Failed to fetch jobs" });
  }
});

// GET /api/gumball/gumballs - Get all gumballs for the authenticated user
router.get("/gumballs", isAuthenticated, async (req, res) => {
  try {
    const userId = (req.user as any)?.claims?.sub;
    
    if (!userId) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    const userGumballs = await db.select()
      .from(gumballs)
      .where(eq(gumballs.visitorId, userId))
      .orderBy(desc(gumballs.createdAt));
    
    res.json(userGumballs);
  } catch (error) {
    console.error("Error fetching gumballs:", error);
    res.status(500).json({ error: "Failed to fetch gumballs" });
  }
});

// POST /api/gumball/deliver - Manual asset delivery
router.post("/deliver", isAuthenticated, async (req, res) => {
  try {
    const { jobId, videoUrl, thumbnailUrl } = req.body;
    const authenticatedUserId = (req.user as any)?.claims?.sub;
    
    if (!jobId) {
      return res.status(400).json({ error: "Missing jobId" });
    }
    
    const job = await db.select()
      .from(gumballJobs)
      .where(eq(gumballJobs.id, jobId))
      .then(r => r[0]);
    
    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }
    
    // Security: Verify the authenticated user owns this job
    if (job.visitorId !== authenticatedUserId) {
      return res.status(403).json({ error: "You do not own this job" });
    }
    
    const createdAssets = [];
    
    // Create video asset if provided
    if (videoUrl) {
      const videoAsset = await db.insert(gumballAssets).values({
        jobId,
        kind: "video",
        url: videoUrl
      }).returning();
      createdAssets.push(videoAsset[0]);
    }
    
    // Create thumbnail asset if provided
    if (thumbnailUrl) {
      const thumbAsset = await db.insert(gumballAssets).values({
        jobId,
        kind: "thumbnail",
        url: thumbnailUrl
      }).returning();
      createdAssets.push(thumbAsset[0]);
    }
    
    // Update job status to DELIVERED
    await db.update(gumballJobs)
      .set({ status: "DELIVERED", updatedAt: new Date() })
      .where(eq(gumballJobs.id, jobId));
    
    res.json({
      success: true,
      assets: createdAssets,
      jobStatus: "DELIVERED"
    });
  } catch (error) {
    console.error("Error delivering gumball assets:", error);
    res.status(500).json({ error: "Failed to deliver assets" });
  }
});

// POST /api/gumball/seed - Seed product tiers (admin endpoint)
router.post("/seed", async (req, res) => {
  try {
    const productTiers = [
      { name: "Pocket Roll", pulls: 5, priceRays: 50 },
      { name: "Creator Roll", pulls: 20, priceRays: 180 },
      { name: "Studio Roll", pulls: 100, priceRays: 800 }
    ];
    
    const createdProducts = [];
    
    for (const tier of productTiers) {
      // Check if product already exists
      const existing = await db.select()
        .from(gumballProducts)
        .where(eq(gumballProducts.name, tier.name))
        .then(r => r[0]);
      
      if (!existing) {
        const product = await db.insert(gumballProducts).values({
          name: tier.name,
          pulls: tier.pulls,
          priceRays: tier.priceRays,
          active: true
        }).returning();
        createdProducts.push(product[0]);
      } else {
        createdProducts.push(existing);
      }
    }
    
    res.json({
      success: true,
      products: createdProducts
    });
  } catch (error) {
    console.error("Error seeding gumball products:", error);
    res.status(500).json({ error: "Failed to seed products" });
  }
});

export default router;
